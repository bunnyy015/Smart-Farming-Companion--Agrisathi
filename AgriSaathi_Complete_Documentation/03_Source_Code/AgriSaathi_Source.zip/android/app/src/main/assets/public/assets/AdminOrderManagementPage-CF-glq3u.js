import{_ as e,l as t,v as n}from"./index-DpPCDqve.js";import{_ as r,f as i,g as a,n as o,x as s}from"./firebase-BWeISr64.js";import{t as c}from"./orderSorting-B7h-MdaU.js";var l=n(e(),1),u=t();function d(e){return String(e||``).trim().toLowerCase()}function f(e){if(!e)return`N/A`;let t=new Date(e);return Number.isNaN(t.getTime())?String(e):t.toLocaleString()}function p(e){let t=d(e?.status||e?.orderStatus||e?.order_status||`pending`);return t?t===`rejected`||t===`reject`?`rejected`:t===`delivered`||t===`delivery`||t===`completed`||t===`complete`?`delivered`:t===`processing`||t===`in progress`||t===`inprogress`||t===`shipped`||t===`out for delivery`?`processing`:t===`pending`||t===`placed`||t===`new`||t===`confirmed`?`pending`:t:`pending`}function m(){let[e,t]=(0,l.useState)([]),[n,m]=(0,l.useState)(!0),[h,g]=(0,l.useState)(``),[_,v]=(0,l.useState)(``),[y,b]=(0,l.useState)(``),[x,S]=(0,l.useState)(``),[C,w]=(0,l.useState)(null);(0,l.useEffect)(()=>{let e=null,n=null,r=(e,t)=>!e||typeof e!=`object`?[]:Object.entries(e).map(([e,n])=>({id:e,...n||{},_sourcePath:t})),s=()=>{let i=[];e&&typeof e==`object`&&Object.keys(e).length>0?i=r(e,`dealerOrders`):n&&typeof n==`object`&&Object.keys(n).length>0&&(i=r(n,`orders`)),i=c(i),t(i),m(!1)},l=i(a(o,`dealerOrders`),t=>{e=t.exists()?t.val():null,s()},t=>{console.error(`Error loading dealerOrders:`,t),e=null,s()}),u=i(a(o,`orders`),e=>{n=e.exists()?e.val():null,s()},e=>{console.error(`Error loading orders:`,e),n=null,s()});return()=>{l(),u()}},[]);let T=e.length,E=e.filter(e=>p(e)===`pending`).length,D=e.filter(e=>p(e)===`processing`).length,O=e.filter(e=>p(e)===`delivered`).length,k=(0,l.useMemo)(()=>{let t=d(h);return c(e.filter(e=>{let n=p(e),r=!_||(_===`completed`?n===`delivered`:n===_),i=[e.id,e.orderId,e.farmerName,e.farmerId,e.productName,e.productId,e.phone,e.mobile,e.dealerName,e.dealerId,e.status].join(` `).toLowerCase(),a=!t||i.includes(t),o=n===`delivered`?e.completedAt||e.updatedAt||e.createdAt:e.createdAt||e.updatedAt,s=o?new Date(o).getTime():NaN,c=y?new Date(`${y}T00:00:00`).getTime():-1/0,l=x?new Date(`${x}T23:59:59.999`).getTime():1/0;return r&&a&&(!y&&!x||Number.isFinite(s)&&s>=c&&s<=l)}))},[e,h,_,y,x]),A=async(t,n)=>{try{w(t);let r=e.find(e=>e.id===t)?._sourcePath||`dealerOrders`;await s(a(o,`${r}/${t}`),{status:n,updatedAt:new Date().toISOString()})}catch(e){console.error(`Error updating order:`,e),alert(`Failed to update order status.`)}finally{w(null)}},j=async t=>{if(window.confirm(`Are you sure you want to delete this order?`))try{let n=e.find(e=>e.id===t)?._sourcePath||`dealerOrders`;await r(a(o,`${n}/${t}`))}catch(e){console.error(`Error deleting order:`,e),alert(`Failed to delete order.`)}},M=e=>{switch(e){case`pending`:return`status pending`;case`processing`:return`status processing`;case`delivered`:return`status delivered`;default:return`status`}};return(0,u.jsxs)(`div`,{className:`admin-orders-page`,children:[(0,u.jsx)(`style`,{children:`
        * {
          box-sizing: border-box;
        }

        .admin-orders-page {
          min-height: 100vh;
          background: #f5f7fb;
          padding: 30px;
          font-family: Arial, sans-serif;
          color: #1f2937;
        }

        .orders-container {
          max-width: 1400px;
          margin: 0 auto;
        }

        .page-header {
          background: linear-gradient(
            135deg,
            #24205f,
            #8b00e8
          );
          color: white;
          border-radius: 20px;
          padding: 28px 32px;
          margin-bottom: 25px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }

        .page-header h1 {
          margin: 0 0 7px;
          font-size: 30px;
        }

        .page-header p {
          margin: 0;
          opacity: 0.9;
        }

        .back-button {
          border: none;
          background: white;
          color: #4c1d95;
          padding: 11px 18px;
          border-radius: 10px;
          cursor: pointer;
          font-weight: bold;
        }

        .back-button:hover {
          opacity: 0.9;
        }

        .stats-grid {
          display: grid;
          grid-template-columns:
            repeat(5, 1fr);
          gap: 18px;
          margin-bottom: 25px;
        }

        .stat-card {
          background: white;
          border-radius: 15px;
          padding: 20px;
          box-shadow:
            0 4px 15px rgba(0,0,0,0.07);
          border: 1px solid #e5e7eb;
        }

        .stat-card h3 {
          margin: 0 0 10px;
          font-size: 15px;
          color: #6b7280;
        }

        .stat-number {
          font-size: 30px;
          font-weight: bold;
        }

        .filters {
          background: white;
          padding: 20px;
          border-radius: 15px;
          margin-bottom: 20px;
          display: flex;
          gap: 15px;
          flex-wrap: wrap;
          box-shadow:
            0 4px 15px rgba(0,0,0,0.06);
        }

        .search-input {
          flex: 1;
          min-width: 250px;
          padding: 12px 15px;
          border: 1px solid #d1d5db;
          border-radius: 9px;
          font-size: 15px;
          outline: none;
        }

        .search-input:focus {
          border-color: #7c3aed;
        }

        .filter-select {
          padding: 12px 15px;
          border: 1px solid #d1d5db;
          border-radius: 9px;
          background: white;
          min-width: 180px;
          font-size: 15px;
        }

        .orders-card {
          background: white;
          border-radius: 15px;
          padding: 20px;
          box-shadow:
            0 4px 15px rgba(0,0,0,0.06);
          overflow-x: auto;
        }

        .orders-title {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 18px;
        }

        .orders-title h2 {
          margin: 0;
        }

        .order-count {
          color: #6b7280;
          font-size: 14px;
        }

        table {
          width: 100%;
          border-collapse: collapse;
          min-width: 1000px;
        }

        th {
          background: #f8fafc;
          text-align: left;
          padding: 14px;
          font-size: 14px;
          color: #475569;
          border-bottom:
            1px solid #e5e7eb;
        }

        td {
          padding: 15px 14px;
          border-bottom:
            1px solid #eef0f3;
          font-size: 14px;
          vertical-align: middle;
        }

        tr:hover {
          background: #fafafa;
        }

        .order-id {
          font-weight: bold;
          color: #4f46e5;
        }

        .product-name {
          font-weight: 600;
        }

        .amount {
          font-weight: bold;
        }

        .status {
          display: inline-block;
          padding: 6px 10px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: bold;
          background: #e5e7eb;
          color: #374151;
        }

        .status.pending {
          background: #fff7ed;
          color: #c2410c;
        }

        .status.processing {
          background: #eff6ff;
          color: #1d4ed8;
        }

        .status.delivered {
          background: #ecfdf5;
          color: #047857;
        }

        .status-select {
          padding: 7px 9px;
          border: 1px solid #d1d5db;
          border-radius: 7px;
          background: white;
        }

        .delete-button {
          border: none;
          background: #fee2e2;
          color: #dc2626;
          padding: 8px 12px;
          border-radius: 7px;
          cursor: pointer;
          font-weight: bold;
        }

        .delete-button:hover {
          background: #fecaca;
        }

        .empty-state {
          text-align: center;
          padding: 50px 20px;
          color: #6b7280;
        }

        .loading {
          text-align: center;
          padding: 50px;
          color: #6b7280;
        }

        @media (max-width: 1000px) {
          .stats-grid {
            grid-template-columns:
              repeat(2, 1fr);
          }

          .page-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
          }
        }

        @media (max-width: 600px) {
          .admin-orders-page {
            padding: 15px;
          }

          .stats-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),(0,u.jsxs)(`div`,{className:`orders-container`,children:[(0,u.jsxs)(`div`,{className:`page-header`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h1`,{children:`📦 Admin Order Management`}),(0,u.jsx)(`p`,{children:`Manage and monitor all farmer orders`})]}),(0,u.jsxs)(`button`,{className:`back-button`,onClick:()=>window.history.back(),children:[(0,u.jsx)(`option`,{value:``,disabled:!0,children:`Filter by status`}),`← Back`]})]}),(0,u.jsxs)(`div`,{className:`stats-grid`,children:[(0,u.jsxs)(`div`,{className:`stat-card`,children:[(0,u.jsx)(`h3`,{children:`Total Orders`}),(0,u.jsx)(`div`,{className:`stat-number`,children:T})]}),(0,u.jsxs)(`div`,{className:`stat-card`,children:[(0,u.jsx)(`h3`,{children:`Pending`}),(0,u.jsx)(`div`,{className:`stat-number`,children:E})]}),(0,u.jsxs)(`div`,{className:`stat-card`,children:[(0,u.jsx)(`h3`,{children:`Processing`}),(0,u.jsx)(`div`,{className:`stat-number`,children:D})]}),(0,u.jsxs)(`div`,{className:`stat-card`,children:[(0,u.jsx)(`h3`,{children:`Delivered`}),(0,u.jsx)(`div`,{className:`stat-number`,children:O})]})]}),(0,u.jsxs)(`div`,{className:`filters`,children:[(0,u.jsx)(`input`,{type:`text`,className:`search-input`,placeholder:`Search by farmer, product, phone or order ID...`,value:h,onChange:e=>g(e.target.value)}),(0,u.jsxs)(`select`,{className:`filter-select`,value:_,onChange:e=>v(e.target.value),children:[(0,u.jsx)(`option`,{value:``,disabled:!0,children:`Filter by status`}),(0,u.jsx)(`option`,{value:`pending`,children:`Pending`}),(0,u.jsx)(`option`,{value:`processing`,children:`Processing`}),(0,u.jsx)(`option`,{value:`delivered`,children:`Delivered`}),(0,u.jsx)(`option`,{value:`completed`,children:`Completed`})]}),(0,u.jsxs)(`label`,{className:`filter-select`,children:[`From date`,(0,u.jsx)(`input`,{type:`date`,value:y,max:x||void 0,onChange:e=>b(e.target.value),"aria-label":`Filter orders from date`})]}),(0,u.jsxs)(`label`,{className:`filter-select`,children:[`To date`,(0,u.jsx)(`input`,{type:`date`,value:x,min:y||void 0,onChange:e=>S(e.target.value),"aria-label":`Filter orders to date`})]})]}),(0,u.jsxs)(`div`,{className:`orders-card`,children:[(0,u.jsxs)(`div`,{className:`orders-title`,children:[(0,u.jsx)(`h2`,{children:`All Orders`}),(0,u.jsxs)(`span`,{className:`order-count`,children:[`Showing `,k.length,` of`,` `,T,` orders`]})]}),n?(0,u.jsx)(`div`,{className:`loading`,children:`Loading orders...`}):k.length===0?(0,u.jsxs)(`div`,{className:`empty-state`,children:[(0,u.jsx)(`h3`,{children:`No orders found`}),(0,u.jsx)(`p`,{children:`There are no orders matching your search or filter.`})]}):(0,u.jsxs)(`table`,{children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`Order ID`}),(0,u.jsx)(`th`,{children:`Farmer`}),(0,u.jsx)(`th`,{children:`Product`}),(0,u.jsx)(`th`,{children:`Quantity`}),(0,u.jsx)(`th`,{children:`Amount`}),(0,u.jsx)(`th`,{children:`Phone`}),(0,u.jsx)(`th`,{children:`Date`}),(0,u.jsx)(`th`,{children:`Status`}),(0,u.jsx)(`th`,{children:`Update`}),(0,u.jsx)(`th`,{children:`Action`})]})}),(0,u.jsx)(`tbody`,{children:k.map(e=>{let t=p(e);return(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:`order-id`,children:e.orderId||e.id})}),(0,u.jsxs)(`td`,{children:[(0,u.jsx)(`strong`,{children:e.farmerName||`Unknown Farmer`}),e.farmerId&&(0,u.jsx)(`div`,{children:e.farmerId})]}),(0,u.jsxs)(`td`,{children:[(0,u.jsx)(`span`,{className:`product-name`,children:e.productName||`Unknown Product`}),e.productId&&(0,u.jsx)(`div`,{children:e.productId})]}),(0,u.jsx)(`td`,{children:e.quantity||0}),(0,u.jsx)(`td`,{children:(0,u.jsxs)(`span`,{className:`amount`,children:[`₹`,e.totalAmount??e.amount??0]})}),(0,u.jsx)(`td`,{children:e.phone||e.mobile||`N/A`}),(0,u.jsx)(`td`,{children:f(e.createdAt)}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:M(t),children:t})}),(0,u.jsx)(`td`,{children:(0,u.jsxs)(`select`,{className:`status-select`,value:t,disabled:C===e.id,onChange:t=>A(e.id,t.target.value),children:[(0,u.jsx)(`option`,{value:`pending`,children:`Pending`}),(0,u.jsx)(`option`,{value:`processing`,children:`Processing`}),(0,u.jsx)(`option`,{value:`delivered`,children:`Delivered`})]})}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`button`,{className:`delete-button`,onClick:()=>j(e.id),children:`Delete`})})]},e.id)})})]})]})]})]})}export{m as default};