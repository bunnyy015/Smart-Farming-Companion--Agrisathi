var e=`agrisathi_weather_context`;function t({location:t,currentWeather:n,hourlyForecast:r=[],dailyForecast:i=[]}){if(!n)return;let a=Date.now(),o=r.filter(e=>new Date(e.time).getTime()>=a).slice(0,12),s=Math.max(0,...o.map(e=>Number(e.rainProbability||0))),c=o.reduce((e,t)=>e+Number(t.precipitation||0),0),l=Math.max(Number(n.wind_speed_10m||0),...o.map(e=>Number(e.windSpeed||0))),u=i[0]||null,d={savedAt:Date.now(),location:{village:t?.village||``,mandal:t?.mandal||``,district:t?.district||``,state:t?.state||``,latitude:Number(t?.latitude),longitude:Number(t?.longitude),accuracy:Number(t?.accuracy),timestamp:Number(t?.timestamp),source:t?.source||``},current:{temperature:Number(n.temperature_2m||0),apparentTemperature:Number(n.apparent_temperature||0),humidity:Number(n.relative_humidity_2m||0),precipitation:Number(n.precipitation||0),rain:Number(n.rain||0),windSpeed:Number(n.wind_speed_10m||0),windGust:Number(n.wind_gusts_10m||0),weatherCode:Number(n.weather_code||0)},forecast:{nextTwelveHoursRainProbability:s,nextTwelveHoursExpectedRain:Number(c.toFixed(1)),maximumWindSpeed:Number(l.toFixed(1)),todayMaximumTemperature:Number(u?.maximumTemperature||0),todayMinimumTemperature:Number(u?.minimumTemperature||0),todayRainProbability:Number(u?.rainProbability||0),todayExpectedRain:Number(u?.rain||0)}};localStorage.setItem(e,JSON.stringify(d))}function n(){try{let t=localStorage.getItem(e);if(!t)return null;let n=JSON.parse(t);if(!n||typeof n!=`object`)return null;let r=Number(n.savedAt||0),i=9e5,a=Date.now()-Number(n.location?.timestamp),o=n.location?.source===`device`&&Number.isFinite(Number(n.location?.latitude))&&Number.isFinite(Number(n.location?.longitude))&&Number.isFinite(Number(n.location?.timestamp))&&a>=-6e4&&a<=i;return!r||Date.now()-r>i||!o?(localStorage.removeItem(e),null):n}catch(e){return console.error(`Weather context reading error:`,e),null}}function r(){let e=n();return e?`
Weather location: ${[e.location?.village,e.location?.mandal,e.location?.district,e.location?.state].filter(Boolean).join(`, `)||`${e.location.latitude.toFixed(4)}, ${e.location.longitude.toFixed(4)}`}

Current conditions:
- Temperature: ${e.current.temperature}°C
- Feels like: ${e.current.apparentTemperature}°C
- Humidity: ${e.current.humidity}%
- Current rain: ${e.current.rain} mm
- Current precipitation: ${e.current.precipitation} mm
- Wind speed: ${e.current.windSpeed} km/h
- Wind gust: ${e.current.windGust} km/h
- Weather code: ${e.current.weatherCode}

Forecast:
- Maximum rain probability during the next 12 hours: ${e.forecast.nextTwelveHoursRainProbability}%
- Expected precipitation during the next 12 hours: ${e.forecast.nextTwelveHoursExpectedRain} mm
- Maximum wind speed during the next 12 hours: ${e.forecast.maximumWindSpeed} km/h
- Today's maximum temperature: ${e.forecast.todayMaximumTemperature}°C
- Today's minimum temperature: ${e.forecast.todayMinimumTemperature}°C
- Today's rain probability: ${e.forecast.todayRainProbability}%
- Today's expected rain: ${e.forecast.todayExpectedRain} mm

Use this data only when answering weather-related farming questions.
Do not claim weather certainty.
Advise the farmer to check the local sky and field conditions before spraying, irrigation, sowing or harvesting.
`.trim():`Current live weather data is unavailable.

Do not assume the weather.
Ask the farmer to open the Weather page and refresh their location when live weather is required.`}function i(){localStorage.removeItem(e)}export{r as n,t as r,i as t};