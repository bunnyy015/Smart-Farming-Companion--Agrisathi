import{_ as e,a as t,c as n,l as r,o as i,p as a,s as o,t as s,v as c}from"./index-DpPCDqve.js";var l=c(e(),1),u=r(),d=[{id:`farmer`,icon:`👨‍🌾`,titleKey:`roleFarmer`,descriptionKey:`roleFarmerDescription`,color:`from-green-500 to-emerald-600`,lightColor:`bg-green-50 border-green-200`},{id:`dealer`,icon:`🏪`,titleKey:`roleDealer`,descriptionKey:`roleDealerDescription`,color:`from-blue-500 to-cyan-600`,lightColor:`bg-blue-50 border-blue-200`},{id:`admin`,icon:`🛡️`,titleKey:`roleAdmin`,descriptionKey:`roleAdminDescription`,color:`from-purple-500 to-indigo-600`,lightColor:`bg-purple-50 border-purple-200`}];function f(){let e=a(),[r,c]=(0,l.useState)(``),[f,p]=(0,l.useState)(!1),[m,h]=(0,l.useState)(s());(0,l.useEffect)(()=>{let e=o(h),t=window.setTimeout(()=>{p(!0)},100);return()=>{window.clearTimeout(t),e()}},[]);function g(e){h(i(e.target.value))}function _(t){c(t),sessionStorage.setItem(`role`,t),window.setTimeout(()=>{e(`/login`)},350)}return(0,u.jsxs)(`div`,{className:`min-h-screen relative overflow-hidden bg-gradient-to-br from-green-100 via-emerald-50 to-green-100 flex items-center justify-center p-4 sm:p-6`,children:[(0,u.jsx)(`div`,{className:`absolute -top-24 -left-24 w-72 h-72 bg-green-300/20 rounded-full blur-3xl animate-pulse`}),(0,u.jsx)(`div`,{className:`absolute -bottom-24 -right-24 w-80 h-80 bg-emerald-300/20 rounded-full blur-3xl animate-pulse`,style:{animationDelay:`700ms`}}),(0,u.jsx)(`div`,{className:`absolute top-1/3 right-10 w-20 h-20 bg-yellow-200/30 rounded-full blur-2xl animate-pulse`,style:{animationDelay:`1200ms`}}),(0,u.jsxs)(`main`,{className:`relative z-10 w-full max-w-6xl transition-all duration-700 ease-out ${f?`opacity-100 translate-y-0`:`opacity-0 translate-y-8`}`,children:[(0,u.jsxs)(`header`,{className:`text-center mb-8 sm:mb-10`,children:[(0,u.jsx)(`img`,{src:`/agrisathi-logo.png`,alt:`AgriSaathi — Smart Farming Companion`,className:`mx-auto mb-4 block w-[min(260px,75vw)] sm:w-[300px] h-auto object-contain`}),(0,u.jsxs)(`label`,{className:`inline-flex items-center gap-3 mt-5 rounded-2xl border border-green-200 bg-white px-4 py-3 shadow-sm`,children:[(0,u.jsxs)(`span`,{className:`font-semibold text-gray-700`,children:[`🌐 `,n(`selectLanguage`,{},m)]}),(0,u.jsx)(`select`,{value:m,onChange:g,className:`rounded-lg border border-green-200 bg-white px-3 py-2 text-green-900`,"aria-label":n(`selectLanguage`,{},m),children:t.map(e=>(0,u.jsx)(`option`,{value:e.code,children:e.nativeName},e.code))})]}),(0,u.jsx)(`p`,{className:`mt-4 text-sm sm:text-base font-semibold text-green-800`,children:n(`selectRoleToContinue`,{},m)})]}),(0,u.jsx)(`section`,{className:`grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6`,children:d.map((e,t)=>{let i=r===e.id,a=n(e.titleKey,{},m);return(0,u.jsxs)(`button`,{type:`button`,onClick:()=>_(e.id),disabled:!!r,"aria-label":n(`continueAsRole`,{role:a},m),className:`
                  group relative text-left
                  bg-white
                  rounded-3xl
                  border
                  ${e.lightColor}
                  shadow-lg
                  overflow-hidden
                  transition-all
                  duration-300
                  ease-out
                  focus:outline-none
                  focus:ring-4
                  focus:ring-green-300/50
                  ${i?`scale-[0.98] shadow-2xl`:`hover:-translate-y-2 hover:shadow-2xl`}
                  ${r&&!i?`opacity-50 scale-[0.98]`:``}
                `,style:{animationDelay:`${t*120}ms`},children:[(0,u.jsx)(`div`,{className:`h-2 bg-gradient-to-r ${e.color}`}),(0,u.jsxs)(`div`,{className:`p-6 sm:p-7`,children:[(0,u.jsxs)(`div`,{className:`flex items-center justify-between`,children:[(0,u.jsx)(`div`,{className:`
                        w-20 h-20
                        rounded-2xl
                        bg-gradient-to-br
                        ${e.color}
                        flex
                        items-center
                        justify-center
                        shadow-lg
                        transform
                        transition-all
                        duration-300
                        ${i?`scale-110 rotate-3`:`group-hover:scale-110 group-hover:-rotate-3`}
                      `,children:(0,u.jsx)(`span`,{className:`text-5xl`,children:e.icon})}),(0,u.jsx)(`div`,{className:`
                        w-10 h-10
                        rounded-full
                        bg-gray-50
                        flex
                        items-center
                        justify-center
                        text-gray-400
                        transition-all
                        duration-300
                        ${i?`bg-green-100 text-green-700 translate-x-1`:`group-hover:bg-green-100 group-hover:text-green-700 group-hover:translate-x-1`}
                      `,children:`→`})]}),(0,u.jsxs)(`div`,{className:`mt-6`,children:[(0,u.jsx)(`h2`,{className:`text-2xl font-bold text-gray-900`,children:a}),(0,u.jsx)(`p`,{className:`text-gray-600 text-sm leading-6 mt-3 min-h-[72px]`,children:n(e.descriptionKey,{},m)})]}),(0,u.jsx)(`div`,{className:`
                      mt-6
                      w-full
                      rounded-xl
                      py-3
                      text-center
                      font-semibold
                      text-sm
                      bg-gradient-to-r
                      ${e.color}
                      text-white
                      shadow-md
                      transition-all
                      duration-300
                      ${i?`scale-[0.98]`:`group-hover:shadow-lg`}
                    `,children:i?n(`openingLogin`,{},m):n(`continueAsRole`,{role:a},m)})]}),(0,u.jsx)(`div`,{className:`
                    absolute
                    inset-0
                    pointer-events-none
                    opacity-0
                    group-hover:opacity-100
                    transition-opacity
                    duration-300
                    bg-gradient-to-br
                    from-white/20
                    to-transparent
                  `})]},e.id)})}),(0,u.jsx)(`footer`,{className:`text-center mt-8`,children:(0,u.jsxs)(`div`,{className:`inline-flex flex-wrap justify-center items-center gap-x-4 gap-y-2 text-xs sm:text-sm text-gray-500`,children:[(0,u.jsxs)(`span`,{className:`flex items-center gap-1.5`,children:[(0,u.jsx)(`span`,{className:`text-green-600`,children:`✓`}),n(`simpleToUse`,{},m)]}),(0,u.jsx)(`span`,{className:`hidden sm:block text-gray-300`,children:`|`}),(0,u.jsxs)(`span`,{className:`flex items-center gap-1.5`,children:[(0,u.jsx)(`span`,{className:`text-green-600`,children:`✓`}),n(`farmerFriendly`,{},m)]}),(0,u.jsx)(`span`,{className:`hidden sm:block text-gray-300`,children:`|`}),(0,u.jsxs)(`span`,{className:`flex items-center gap-1.5`,children:[(0,u.jsx)(`span`,{className:`text-green-600`,children:`✓`}),n(`secureAccess`,{},m)]})]})})]})]})}export{f as default};