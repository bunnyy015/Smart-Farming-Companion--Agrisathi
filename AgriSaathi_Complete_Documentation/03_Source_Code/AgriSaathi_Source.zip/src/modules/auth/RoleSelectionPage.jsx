import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Info } from "lucide-react";
import {
  getLanguage,
  languages,
  setLanguage,
  subscribeLanguageChange,
  t,
} from "../../utils/language";
import "./RoleSelectionPage.css";

const roles = [
  {
    id: "farmer",
    icon: "👨‍🌾",
    titleKey: "roleFarmer",
    descriptionKey: "roleFarmerDescription",
    color:
      "from-green-500 to-emerald-600",
    lightColor:
      "bg-green-50 border-green-200",
  },
  {
    id: "dealer",
    icon: "🏪",
    titleKey: "roleDealer",
    descriptionKey: "roleDealerDescription",
    color:
      "from-blue-500 to-cyan-600",
    lightColor:
      "bg-blue-50 border-blue-200",
  },
  {
    id: "admin",
    icon: "🛡️",
    titleKey: "roleAdmin",
    descriptionKey: "roleAdminDescription",
    color:
      "from-purple-500 to-indigo-600",
    lightColor:
      "bg-purple-50 border-purple-200",
  },
];

export default function RoleSelectionPage() {
  const navigate = useNavigate();

  const [selectedRole, setSelectedRole] = useState("");
  const [isVisible, setIsVisible] = useState(false);
  const [language, setCurrentLanguage] = useState(getLanguage());

  useEffect(() => {
    const unsubscribe = subscribeLanguageChange(setCurrentLanguage);
    const timer = window.setTimeout(() => {
      setIsVisible(true);
    }, 100);

    return () => {
      window.clearTimeout(timer);
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    const page = document.querySelector(".role-selection-page");
    const pointerQuery = window.matchMedia("(hover: hover) and (pointer: fine)");
    if (!page || !pointerQuery.matches) return undefined;

    function moveLandscape(event) {
      const x = (event.clientX / window.innerWidth - 0.5) * 2;
      page.style.setProperty("--pointer-x", `${x.toFixed(3)}`);
      const y = (event.clientY / window.innerHeight - 0.5) * 2;
      page.style.setProperty("--pointer-y", `${y.toFixed(3)}`);
    }
    window.addEventListener("pointermove", moveLandscape, { passive: true });
    return () => window.removeEventListener("pointermove", moveLandscape);
  }, []);

  function handleLanguageChange(event) {
    setCurrentLanguage(setLanguage(event.target.value));
  }

  function selectRole(role) {
    setSelectedRole(role);

    sessionStorage.setItem("role", role);

    window.setTimeout(() => {
      navigate("/login");
    }, 350);
  }

  return (
    <div className="role-selection-page min-h-screen relative overflow-hidden bg-gradient-to-br from-green-100 via-emerald-50 to-green-100 flex items-center justify-center p-4 sm:p-6">
      <div className="role-landscape" aria-hidden="true">
        <div className="landscape-sun" />
        <div className="landscape-cloud cloud-one" />
        <div className="landscape-cloud cloud-two" />
        <div className="landscape-field field-far" />
        <div className="landscape-field field-mid" />
        <div className="landscape-field field-near" />
        <div className="landscape-crops" />
        <span className="nature-speck speck-one" />
        <span className="nature-speck speck-two" />
        <span className="nature-speck speck-three" />
        <span className="nature-leaf leaf-one" />
        <span className="nature-leaf leaf-two" />
      </div>

      {/* Main container */}
      <main
        className={`relative z-10 w-full max-w-6xl role-content transition-all duration-700 ease-out ${
          isVisible
            ? "opacity-100 translate-y-0"
            : "opacity-0 translate-y-8"
        }`}
      >
        {/* Header */}
        <header className="text-center mb-8 sm:mb-10">
          <img
            src="/agrisathi-logo.png"
            alt="AgriSaathi — Smart Farming Companion"
            className="role-logo mx-auto mb-4 block w-[min(260px,75vw)] sm:w-[300px] h-auto object-contain"
          />

          <label className="role-language inline-flex items-center gap-3 mt-5 rounded-2xl border border-green-200 bg-white px-4 py-3 shadow-sm">
            <span className="font-semibold text-gray-700">🌐 {t("selectLanguage", {}, language)}</span>
            <select
              value={language}
              onChange={handleLanguageChange}
              className="rounded-lg border border-green-200 bg-white px-3 py-2 text-green-900"
              aria-label={t("selectLanguage", {}, language)}
            >
              {languages.map((languageOption) => (
                <option
                  key={languageOption.code}
                  value={languageOption.code}
                >
                  {languageOption.nativeName}
                </option>
              ))}
            </select>
          </label>

          <p className="mt-4 text-sm sm:text-base font-semibold text-green-800">
            {t("selectRoleToContinue", {}, language)}
          </p>
        </header>

        {/* Role cards */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6">
          {roles.map((role, index) => {
            const isSelected =
              selectedRole === role.id;
            const roleTitle = t(role.titleKey, {}, language);

            return (
              <button
                key={role.id}
                type="button"
                onClick={() =>
                  selectRole(role.id)
                }
                disabled={Boolean(selectedRole)}
                aria-label={t("continueAsRole", { role: roleTitle }, language)}
                className={`
                  role-card
                  group relative text-left
                  bg-white
                  rounded-3xl
                  border
                  ${role.lightColor}
                  shadow-lg
                  overflow-hidden
                  transition-all
                  duration-300
                  ease-out
                  focus:outline-none
                  focus:ring-4
                  focus:ring-green-300/50
                  ${
                    isSelected
                      ? "scale-[0.98] shadow-2xl"
                      : "hover:-translate-y-2 hover:shadow-2xl"
                  }
                  ${
                    selectedRole &&
                    !isSelected
                      ? "opacity-50 scale-[0.98]"
                      : ""
                  }
                `}
                style={{ "--card-index": index }}
              >
                {/* Top gradient */}
                <div
                  className={`h-2 bg-gradient-to-r ${role.color}`}
                />

                <div className="p-6 sm:p-7">
                  {/* Icon */}
                  <div className="flex items-center justify-between">
                    <div
                      className={`
                        w-20 h-20
                        rounded-2xl
                        bg-gradient-to-br
                        ${role.color}
                        flex
                        items-center
                        justify-center
                        shadow-lg
                        transform
                        transition-all
                        duration-300
                        ${
                          isSelected
                            ? "scale-110 rotate-3"
                            : "group-hover:scale-110 group-hover:-rotate-3"
                        }
                      `}
                    >
                      <span className="text-5xl">
                        {role.icon}
                      </span>
                    </div>

                    {/* Arrow */}
                    <div
                      className={`
                        w-10 h-10
                        rounded-full
                        bg-gray-50
                        flex
                        items-center
                        justify-center
                        text-gray-400
                        transition-all
                        duration-300
                        ${
                          isSelected
                            ? "bg-green-100 text-green-700 translate-x-1"
                            : "group-hover:bg-green-100 group-hover:text-green-700 group-hover:translate-x-1"
                        }
                      `}
                    >
                      →
                    </div>
                  </div>

                  {/* Content */}
                  <div className="mt-6">
                    <h2 className="text-2xl font-bold text-gray-900">
                      {roleTitle}
                    </h2>

                    <p className="text-gray-600 text-sm leading-6 mt-3 min-h-[72px]">
                      {t(role.descriptionKey, {}, language)}
                    </p>
                  </div>

                  {/* Continue indicator */}
                  <div
                    className={`
                      mt-6
                      w-full
                      rounded-xl
                      py-3
                      text-center
                      font-semibold
                      text-sm
                      bg-gradient-to-r
                      ${role.color}
                      text-white
                      shadow-md
                      transition-all
                      duration-300
                      ${
                        isSelected
                          ? "scale-[0.98]"
                          : "group-hover:shadow-lg"
                      }
                    `}
                  >
                    {isSelected
                      ? t("openingLogin", {}, language)
                      : t("continueAsRole", { role: roleTitle }, language)}
                  </div>
                </div>

                {/* Hover glow */}
                <div
                  className={`
                    absolute
                    inset-0
                    pointer-events-none
                    opacity-0
                    group-hover:opacity-100
                    transition-opacity
                    duration-300
                    bg-gradient-to-br
                    from-white/20
                    to-transparent
                  `}
                />
              </button>
            );
          })}
        </section>

        {/* Footer information */}
        <footer className="text-center mt-8">
          <div className="inline-flex flex-wrap justify-center items-center gap-x-4 gap-y-2 text-xs sm:text-sm text-gray-500">
            <span className="flex items-center gap-1.5">
              <span className="text-green-600">
                ✓
              </span>
              {t("simpleToUse", {}, language)}
            </span>

            <span className="hidden sm:block text-gray-300">
              |
            </span>

            <span className="flex items-center gap-1.5">
              <span className="text-green-600">
                ✓
              </span>
              {t("farmerFriendly", {}, language)}
            </span>

            <span className="hidden sm:block text-gray-300">
              |
            </span>

            <span className="flex items-center gap-1.5">
              <span className="text-green-600">
                ✓
              </span>
              {t("secureAccess", {}, language)}
            </span>
          </div>
        </footer>
      </main>

      <nav className="role-info-actions" aria-label="AgriSaathi information">
        <button type="button" onClick={() => navigate("/about?section=about")}>
          <Info size={16} aria-hidden="true" /> {language === "te" ? "మా గురించి · సంప్రదింపు" : language === "hi" ? "परिचय · संपर्क" : language === "kn" ? "ನಮ್ಮ ಬಗ್ಗೆ · ಸಂಪರ್ಕ" : language === "ta" ? "எங்களைப் பற்றி · தொடர்பு" : "About & Contact"}
        </button>
      </nav>
    </div>
  );
}
