import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { get, ref } from "firebase/database";
import { database, getAuthUser } from "../../firebase";
import StatusMessage from "../../components/StatusMessage";
import useLanguage from "../../utils/useLanguage";
import { t } from "../../utils/language";
import {
  fetchGovernmentMarketPrices,
  getGovernmentMarketPriceErrorMessage,
} from "../../services/marketPriceService";
import {
  getCurrentLocation,
  getLocationErrorTranslationKey,
  reverseGeocodeCoordinates,
} from "../../services/currentLocationService";
import "./MarketPricesPage.css";

const LGD_API_ROOT =
  "https://lgd-json-api.vercel.app/api";

const SELLING_POINT_RADIUS = 50000;

// Manual-selection fallback for when the LGD directory API is unavailable.
const INDIA_STATE_CHOICES = [
  "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh",
  "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir",
  "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh",
  "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha",
  "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana",
  "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
];

const STATE_NAMES = {
  telangana: "Telangana",
  "andhra pradesh": "Andhra Pradesh",
  maharashtra: "Maharashtra",
  karnataka: "Karnataka",
  "tamil nadu": "Tamil Nadu",
  tamilnadu: "Tamil Nadu",
  kerala: "Kerala",
  gujarat: "Gujarat",
  punjab: "Punjab",
  odisha: "Odisha",
  orissa: "Odisha",
  bihar: "Bihar",
  "west bengal": "West Bengal",
  rajasthan: "Rajasthan",
  "uttar pradesh": "Uttar Pradesh",
  "madhya pradesh": "Madhya Pradesh",
  haryana: "Haryana",
  chhattisgarh: "Chhattisgarh",
  jharkhand: "Jharkhand",
  assam: "Assam",
  goa: "Goa",
};

async function fetchLgdRecords(collection, filters = {}) {
  const records = [];
  let page = 1;
  let pageCount;

  do {
    const parameters = new URLSearchParams({
      ...filters,
      limit: "100",
      page: String(page),
    });
    const response = await fetch(
      `${LGD_API_ROOT}/${collection}?${parameters.toString()}`
    );

    if (!response.ok) {
      throw new Error("Administrative location data is unavailable.");
    }

    const result = await response.json();
    records.push(...(Array.isArray(result?.data) ? result.data : []));
    pageCount = Number(result?.pagination?.pages || 1);
    page += 1;
  } while (page <= pageCount);

  return records;
}

const CATEGORY_ICONS = {
  cereals: "🌾",
  pulses: "🫘",
  vegetables: "🥬",
  fruits: "🍎",
  spices: "🌶️",
  oilseeds: "🌻",
  fibre: "🧶",
  other: "🌱",
};

function normalizeText(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function normalizeStateName(value) {
  const normalized = normalizeText(value);
  return STATE_NAMES[normalized] || String(value || "").trim();
}

function normalizeDistrictName(value) {
  return String(value || "")
    .replace(/\s+district$/i, "")
    .trim();
}

function normalizeDistrictKey(value) {
  const district = normalizeDistrictName(value)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

  const aliases = {
    jagtial: "jagtial",
    jagitial: "jagtial",
    jangaon: "jangaon",
    jangoan: "jangaon",
    komarambheemasifabad: "kumurambheemasifabad",
    kumurambheemasifabad: "kumurambheemasifabad",
    rangareddy: "rangareddy",
    medchalmalkajgiri: "medchalmalkajgiri",
  };

  return aliases[district] || district;
}

const CROP_SEARCH_ALIASES = {
  rice: ["rice", "paddy"],
  paddy: ["paddy", "rice"],
  soybean: ["soybean", "soyabean", "soya bean"],
  soyabean: ["soyabean", "soybean", "soya bean"],
  "soya bean": ["soya bean", "soybean", "soyabean"],
  arhar: ["arhar", "tur", "red gram"],
  tur: ["tur", "arhar", "red gram"],
  "red gram": ["red gram", "arhar", "tur"],
  corn: ["corn", "maize"],
  maize: ["maize", "corn"],
  "lady finger": ["lady finger", "ladies finger", "okra"],
  "ladies finger": ["ladies finger", "lady finger", "okra"],
  okra: ["okra", "lady finger", "ladies finger"],
};

function getCropSearchTerms(value) {
  const crops = normalizeText(value)
    .split(/[,;]+/)
    .map((crop) => crop.trim())
    .filter(Boolean);

  return [
    ...new Set(
      crops.flatMap((crop) =>
        CROP_SEARCH_ALIASES[crop] || [crop]
      )
    ),
  ];
}

function numberValue(value) {
  const parsed = Number(
    String(value ?? "")
      .replace(/,/g, "")
      .trim()
  );

  return Number.isFinite(parsed) ? parsed : 0;
}

function formatCurrency(value) {
  return Number(value || 0).toLocaleString("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  });
}

function getCropCategory(commodity) {
  const value = normalizeText(commodity);

  const cereals = [
    "paddy",
    "rice",
    "wheat",
    "maize",
    "corn",
    "jowar",
    "bajra",
    "ragi",
    "barley",
    "millet",
    "sorghum",
  ];

  const pulses = [
    "gram",
    "dal",
    "tur",
    "arhar",
    "red gram",
    "green gram",
    "black gram",
    "lentil",
    "moong",
    "urad",
    "chickpea",
  ];

  const vegetables = [
    "tomato",
    "beetroot",
    "onion",
    "potato",
    "brinjal",
    "cabbage",
    "cauliflower",
    "carrot",
    "beans",
    "cucumber",
    "okra",
    "ladies finger",
    "pumpkin",
    "gourd",
  ];

  const fruits = [
    "mango",
    "banana",
    "apple",
    "orange",
    "grapes",
    "papaya",
    "watermelon",
    "guava",
    "pomegranate",
    "lemon",
  ];

  const spices = [
    "turmeric",
    "pepper",
    "coriander",
    "cumin",
    "ginger",
    "garlic",
    "cardamom",
    "chillies",
    "chilli",
    "chili",
  ];

  const oilseeds = [
    "groundnut",
    "soyabean",
    "soybean",
    "sunflower",
    "mustard",
    "sesamum",
    "sesame",
    "castor",
  ];

  const fibre = ["cotton", "jute"];

  if (cereals.some((item) => value.includes(item))) {
    return "cereals";
  }

  if (pulses.some((item) => value.includes(item))) {
    return "pulses";
  }

  if (vegetables.some((item) => value.includes(item))) {
    return "vegetables";
  }

  if (fruits.some((item) => value.includes(item))) {
    return "fruits";
  }

  if (spices.some((item) => value.includes(item))) {
    return "spices";
  }

  if (oilseeds.some((item) => value.includes(item))) {
    return "oilseeds";
  }

  if (fibre.some((item) => value.includes(item))) {
    return "fibre";
  }

  return "other";
}

function parseArrivalDate(value) {
  if (!value) {
    return 0;
  }

  const text = String(value).trim();
  const parts = text.split(/[/-]/);

  if (parts.length === 3) {
    const first = Number(parts[0]);
    const second = Number(parts[1]);
    const third = Number(parts[2]);

    if (/^\d{4}$/.test(parts[0])) {
      return new Date(first, second - 1, third).getTime();
    }

    if (
      Number.isFinite(first) &&
      Number.isFinite(second) &&
      Number.isFinite(third)
    ) {
      const year =
        third < 100 ? 2000 + third : third;

      return new Date(
        year,
        second - 1,
        first
      ).getTime();
    }
  }

  const timestamp = new Date(text).getTime();
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

function calculateDistance(
  firstLatitude,
  firstLongitude,
  secondLatitude,
  secondLongitude
) {
  const earthRadius = 6371;

  const latitudeDifference =
    ((secondLatitude - firstLatitude) * Math.PI) / 180;

  const longitudeDifference =
    ((secondLongitude - firstLongitude) * Math.PI) / 180;

  const firstLatitudeRadians =
    (firstLatitude * Math.PI) / 180;

  const secondLatitudeRadians =
    (secondLatitude * Math.PI) / 180;

  const calculation =
    Math.sin(latitudeDifference / 2) ** 2 +
    Math.cos(firstLatitudeRadians) *
      Math.cos(secondLatitudeRadians) *
      Math.sin(longitudeDifference / 2) ** 2;

  const angle =
    2 *
    Math.atan2(
      Math.sqrt(calculation),
      Math.sqrt(1 - calculation)
    );

  return earthRadius * angle;
}

function svgToDataUri(svg) {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function buildCircleImage(background, inner) {
  return svgToDataUri(`
    <svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
      <rect width="120" height="120" rx="24" fill="${background}" />
      ${inner}
    </svg>
  `);
}

const CROP_IMAGES = {
  paddy: buildCircleImage(
    "#fef3c7",
    `
      <rect x="0" y="80" width="120" height="40" fill="#86efac"/>
      <path d="M58 18 L58 88" stroke="#65a30d" stroke-width="4" stroke-linecap="round"/>
      <path d="M58 32 C44 22, 36 20, 28 28" stroke="#84cc16" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M58 44 C72 34, 82 30, 92 38" stroke="#84cc16" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M58 54 C42 48, 34 48, 24 58" stroke="#84cc16" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M58 62 C72 56, 84 58, 94 66" stroke="#84cc16" stroke-width="4" fill="none" stroke-linecap="round"/>
      <circle cx="73" cy="27" r="3" fill="#facc15"/>
      <circle cx="77" cy="31" r="3" fill="#facc15"/>
      <circle cx="80" cy="35" r="3" fill="#facc15"/>
      <circle cx="84" cy="39" r="3" fill="#facc15"/>
      <circle cx="87" cy="43" r="3" fill="#facc15"/>
      <circle cx="70" cy="34" r="3" fill="#facc15"/>
      <circle cx="74" cy="38" r="3" fill="#facc15"/>
      <circle cx="78" cy="42" r="3" fill="#facc15"/>
    `
  ),

  tomato: buildCircleImage(
    "#fee2e2",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <circle cx="60" cy="58" r="24" fill="#ef4444"/>
      <path d="M60 34 L66 42 L76 40 L72 50 L80 58 L68 58 L60 68 L52 58 L40 58 L48 50 L44 40 L54 42 Z" fill="#16a34a"/>
      <rect x="58" y="22" width="4" height="14" rx="2" fill="#15803d"/>
    `
  ),

  onion: buildCircleImage(
    "#ede9fe",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <path d="M60 28 C78 44 82 54 82 68 C82 81 72 92 60 92 C48 92 38 81 38 68 C38 54 42 44 60 28 Z" fill="#a78bfa"/>
      <path d="M60 28 C54 20 52 14 54 8" stroke="#16a34a" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M52 44 C58 54 58 74 52 86" stroke="#c4b5fd" stroke-width="3" fill="none"/>
      <path d="M68 44 C62 54 62 74 68 86" stroke="#c4b5fd" stroke-width="3" fill="none"/>
    `
  ),

  potato: buildCircleImage(
    "#ffedd5",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <ellipse cx="60" cy="62" rx="28" ry="22" fill="#c2410c"/>
      <circle cx="48" cy="58" r="2.5" fill="#7c2d12"/>
      <circle cx="64" cy="50" r="2.5" fill="#7c2d12"/>
      <circle cx="72" cy="66" r="2.5" fill="#7c2d12"/>
      <circle cx="54" cy="72" r="2.5" fill="#7c2d12"/>
    `
  ),

  chilli: buildCircleImage(
    "#dcfce7",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <path d="M38 58 C46 38, 78 32, 84 56 C88 68, 80 82, 60 84 C42 86, 30 74, 38 58 Z" fill="#ef4444"/>
      <path d="M34 54 C38 48, 46 46, 52 48" stroke="#16a34a" stroke-width="5" fill="none" stroke-linecap="round"/>
      <circle cx="78" cy="56" r="4" fill="#fca5a5"/>
    `
  ),

  maize: buildCircleImage(
    "#fef9c3",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <ellipse cx="60" cy="56" rx="18" ry="28" fill="#facc15"/>
      <path d="M44 54 C36 40, 34 34, 38 24 C48 32, 54 40, 56 52" fill="#16a34a"/>
      <path d="M76 54 C84 40, 86 34, 82 24 C72 32, 66 40, 64 52" fill="#16a34a"/>
      <g fill="#fde047">
        <circle cx="54" cy="42" r="3"/>
        <circle cx="60" cy="42" r="3"/>
        <circle cx="66" cy="42" r="3"/>
        <circle cx="54" cy="50" r="3"/>
        <circle cx="60" cy="50" r="3"/>
        <circle cx="66" cy="50" r="3"/>
        <circle cx="54" cy="58" r="3"/>
        <circle cx="60" cy="58" r="3"/>
        <circle cx="66" cy="58" r="3"/>
        <circle cx="54" cy="66" r="3"/>
        <circle cx="60" cy="66" r="3"/>
        <circle cx="66" cy="66" r="3"/>
      </g>
    `
  ),

  cotton: buildCircleImage(
    "#eff6ff",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <path d="M60 28 L60 88" stroke="#16a34a" stroke-width="4" stroke-linecap="round"/>
      <path d="M60 44 C48 36, 44 34, 38 38" stroke="#16a34a" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M60 54 C72 46, 78 44, 84 48" stroke="#16a34a" stroke-width="4" fill="none" stroke-linecap="round"/>
      <circle cx="44" cy="38" r="11" fill="#ffffff" stroke="#d1d5db" stroke-width="2"/>
      <circle cx="76" cy="48" r="11" fill="#ffffff" stroke="#d1d5db" stroke-width="2"/>
      <circle cx="60" cy="62" r="13" fill="#ffffff" stroke="#d1d5db" stroke-width="2"/>
    `
  ),

  banana: buildCircleImage(
    "#fef3c7",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <path d="M38 66 C44 38, 70 26, 88 28 C84 58, 62 78, 44 78 C40 78, 38 74, 38 66 Z" fill="#facc15"/>
      <path d="M42 66 C50 46, 68 36, 82 36" stroke="#fde68a" stroke-width="4" fill="none" stroke-linecap="round"/>
      <rect x="84" y="27" width="6" height="8" rx="3" fill="#16a34a"/>
    `
  ),

  turmeric: buildCircleImage(
    "#fef3c7",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <ellipse cx="48" cy="62" rx="12" ry="18" fill="#f59e0b"/>
      <ellipse cx="62" cy="56" rx="11" ry="16" fill="#f59e0b"/>
      <ellipse cx="74" cy="64" rx="10" ry="14" fill="#f59e0b"/>
      <path d="M60 24 L60 50" stroke="#16a34a" stroke-width="4" stroke-linecap="round"/>
      <path d="M60 26 C48 18, 42 16, 36 20" stroke="#22c55e" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M60 30 C72 20, 80 18, 88 22" stroke="#22c55e" stroke-width="4" fill="none" stroke-linecap="round"/>
    `
  ),

  okra: buildCircleImage(
    "#e6f7df",
    `
      <path d="M44 81 C37 67 39 44 54 28 C61 21 68 20 76 23 C77 44 68 67 54 83 C50 87 46 86 44 81Z" fill="#20a558"/>
      <path d="M53 78 C56 59 62 40 72 25 M49 68 L43 57 M54 57 L48 46 M60 45 L56 35 M58 63 L68 57 M63 48 L73 43" stroke="#a7e58e" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M67 24 Q72 15 82 18 Q78 25 70 28" fill="#16834b"/>
    `
  ),

  bitterGourd: buildCircleImage(
    "#e5f5df",
    `
      <path d="M29 62 C32 42 46 35 62 39 C77 42 91 52 90 64 C88 77 73 84 57 80 C40 77 27 75 29 62Z" fill="#278d48"/>
      <path d="M36 54 L43 49 L48 55 L54 47 L60 54 L67 48 L73 57 L81 54 M35 66 L43 61 L49 68 L56 60 L62 68 L69 61 L76 70 L84 65" stroke="#75c66a" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M29 60 L23 56 M89 63 L96 60" stroke="#146b3d" stroke-width="4" stroke-linecap="round"/>
    `
  ),

  bottleGourd: buildCircleImage(
    "#edf8e5",
    `
      <path d="M53 32 C48 26 51 19 60 18 C69 17 72 24 67 31 C81 43 86 57 80 73 C75 87 45 91 38 75 C31 59 39 43 53 32Z" fill="#a5ce79"/>
      <path d="M59 20 L60 13 M49 43 C45 54 45 68 50 79 M67 42 C74 55 74 69 69 80" stroke="#d8edb7" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M60 15 Q69 8 76 14 Q70 21 61 20" fill="#25864a"/>
    `
  ),

  cabbage: buildCircleImage(
    "#e8f6df",
    `
      <circle cx="60" cy="60" r="32" fill="#79c85c"/>
      <path d="M34 62 C32 43 48 31 62 36 C78 31 91 46 85 62 C86 77 70 88 58 82 C44 87 31 76 34 62Z" fill="#a6dc7d" stroke="#5aa746" stroke-width="2"/>
      <path d="M60 39 C49 48 46 67 60 81 M60 39 C73 48 76 66 60 81 M39 58 Q59 56 81 58 M43 73 Q59 67 77 73" fill="none" stroke="#e3f5c9" stroke-width="3" stroke-linecap="round"/>
    `
  ),

  cucumber: buildCircleImage(
    "#e3f5df",
    `
      <path d="M38 82 C34 72 37 45 47 32 C53 24 67 24 74 33 C83 46 85 70 78 82 C70 91 46 91 38 82Z" fill="#25894b"/>
      <path d="M47 35 C43 49 43 68 47 82 M59 29 C55 47 56 69 60 86 M71 34 C68 49 70 68 73 81" stroke="#8bd26d" stroke-width="3" fill="none" stroke-linecap="round"/>
      <circle cx="50" cy="43" r="1.5" fill="#d4efad"/><circle cx="68" cy="54" r="1.5" fill="#d4efad"/><circle cx="50" cy="69" r="1.5" fill="#d4efad"/><circle cx="70" cy="75" r="1.5" fill="#d4efad"/>
    `
  ),

  beans: buildCircleImage(
    "#e9f7df",
    `
      <path d="M36 80 C47 67 58 49 77 34 C86 27 93 33 86 42 C69 58 52 73 38 85Z" fill="#2c9b50"/>
      <path d="M33 60 C46 51 58 39 71 27 C79 21 86 27 78 35 C66 48 49 61 36 66Z" fill="#66bc52"/>
      <path d="M42 77 Q57 61 80 39 M39 59 Q54 45 74 31" stroke="#b7e58b" stroke-width="2" fill="none" stroke-linecap="round"/>
      <circle cx="50" cy="68" r="2" fill="#b7e58b"/><circle cx="60" cy="57" r="2" fill="#b7e58b"/><circle cx="52" cy="48" r="2" fill="#d7f2a8"/><circle cx="64" cy="39" r="2" fill="#d7f2a8"/>
    `
  ),

  orange: buildCircleImage(
    "#fff1dc",
    `
      <circle cx="60" cy="61" r="30" fill="#f68a22"/>
      <circle cx="50" cy="51" r="7" fill="#ffb54c" opacity=".75"/>
      <circle cx="60" cy="61" r="25" fill="none" stroke="#ffd17c" stroke-width="2" opacity=".8"/>
      <path d="M60 31 Q62 20 72 18 Q72 28 63 34" fill="#278d4b"/>
    `
  ),

  grapes: buildCircleImage(
    "#f0eaff",
    `
      <path d="M58 24 Q67 17 76 24" stroke="#218247" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M65 24 C63 32 61 36 57 40" stroke="#218247" stroke-width="3" fill="none"/>
      <g fill="#7651b5"><circle cx="48" cy="45" r="10"/><circle cx="67" cy="43" r="10"/><circle cx="39" cy="62" r="10"/><circle cx="58" cy="61" r="11"/><circle cx="77" cy="61" r="10"/><circle cx="49" cy="79" r="10"/><circle cx="67" cy="79" r="10"/><circle cx="58" cy="94" r="8"/></g>
      <g fill="#c8b5ef"><circle cx="45" cy="42" r="3"/><circle cx="64" cy="40" r="3"/><circle cx="36" cy="59" r="3"/><circle cx="55" cy="57" r="3"/></g>
    `
  ),

  carrot: buildCircleImage(
    "#fff0df",
    `
      <path d="M48 40 C62 35 77 41 78 53 C77 66 68 81 58 95 C54 101 49 97 48 91 C45 75 40 57 42 48Z" fill="#f17c24"/>
      <path d="M47 41 Q37 28 42 17 Q53 23 54 39 M54 39 Q55 22 68 16 Q72 29 60 42 M52 39 Q47 27 50 16" fill="#31a255"/>
      <path d="M49 55 L60 52 M51 68 L62 64 M54 80 L61 77" stroke="#ffbd6c" stroke-width="3" stroke-linecap="round"/>
    `
  ),

  beetroot: buildCircleImage(
    "#f8e8ef",
    `
      <path d="M60 38 C77 34 87 48 80 65 C75 78 66 86 60 96 C54 86 44 78 39 65 C32 48 43 34 60 38Z" fill="#a62653"/>
      <path d="M60 89 C59 98 56 103 53 108" stroke="#a62653" stroke-width="3" stroke-linecap="round"/>
      <path d="M59 41 C47 31 45 20 51 13 C61 21 63 29 61 39 M62 40 C68 27 78 23 86 28 C79 37 71 41 62 43 M57 39 C45 39 36 33 37 25 C48 25 55 30 59 38" fill="#4c9b4e" stroke="#358848" stroke-width="2" stroke-linejoin="round"/>
      <path d="M47 58 C49 50 56 47 63 49" stroke="#df6b8d" stroke-width="3" fill="none" stroke-linecap="round" opacity=".75"/>
    `
  ),

  cauliflower: buildCircleImage(
    "#f0f7df",
    `
      <path d="M36 66 C29 53 39 42 49 44 C51 31 70 31 74 45 C90 43 96 61 84 70 C85 85 69 90 60 81 C47 91 32 82 36 66Z" fill="#fffdf0" stroke="#d8dfb6" stroke-width="3"/>
      <path d="M47 77 L40 88 L53 84 M73 78 L81 88 L67 84 M57 81 L57 94 L64 94 L64 81" fill="#65ad50"/>
      <path d="M49 49 Q55 42 61 49 M70 53 Q77 48 81 55 M46 65 Q51 59 56 65" stroke="#ece8cc" stroke-width="2" fill="none"/>
    `
  ),

  pumpkin: buildCircleImage(
    "#fff1dc",
    `
      <path d="M60 35 C42 29 31 43 33 62 C33 81 43 89 60 84 C77 90 88 78 87 60 C87 42 76 30 60 35Z" fill="#ef8b28"/>
      <path d="M60 36 C52 47 52 72 60 84 M60 36 C69 48 69 73 60 84 M43 40 C50 51 50 70 44 81 M77 40 C70 51 70 70 76 81" stroke="#ffbd60" stroke-width="3" fill="none"/>
      <path d="M58 36 Q58 25 68 22 L72 25 L64 39" fill="#438d3c"/>
    `
  ),

  guava: buildCircleImage(
    "#edf7df",
    `
      <path d="M60 34 C80 34 91 48 85 68 C80 86 69 92 57 86 C42 91 31 78 34 60 C36 43 46 34 60 34Z" fill="#78ba48"/>
      <path d="M60 41 C75 42 82 53 77 68 C73 80 66 84 58 80 C47 84 40 75 43 61 C45 49 50 41 60 41Z" fill="#f4a4a1"/>
      <g fill="#f8e6a2"><circle cx="54" cy="55" r="2"/><circle cx="65" cy="52" r="2"/><circle cx="60" cy="64" r="2"/><circle cx="69" cy="68" r="2"/><circle cx="53" cy="72" r="2"/></g>
      <path d="M59 35 Q65 25 76 28 Q72 37 61 39" fill="#218247"/>
    `
  ),

  pomegranate: buildCircleImage(
    "#fff0e9",
    `
      <path d="M60 34 L67 27 L73 34 L82 35 L78 44 C90 61 83 84 61 88 C39 86 31 65 43 45 L39 36 L51 35 L56 28Z" fill="#c92c4a"/>
      <path d="M60 34 L55 25 L62 29 L68 23 L69 34" fill="#258448"/>
      <path d="M48 54 C51 47 56 45 60 50 C65 44 72 49 72 56 C72 66 66 71 60 70 C53 72 47 65 48 54Z" fill="#f06b77"/>
      <g fill="#ffd0a0"><circle cx="55" cy="56" r="2"/><circle cx="64" cy="55" r="2"/><circle cx="60" cy="63" r="2"/></g>
    `
  ),

  papaya: buildCircleImage(
    "#fff2df",
    `
      <path d="M47 27 C63 21 79 30 82 47 C85 65 73 84 60 96 C49 85 37 66 38 49 C38 39 40 31 47 27Z" fill="#f49a35"/>
      <path d="M49 35 C60 31 71 38 73 51 C75 65 66 78 59 85 C50 75 44 62 44 50 C44 43 45 38 49 35Z" fill="#f7c564"/>
      <g fill="#5c3d2e"><ellipse cx="54" cy="47" rx="2.4" ry="3.3"/><ellipse cx="62" cy="45" rx="2.4" ry="3.3"/><ellipse cx="55" cy="57" rx="2.4" ry="3.3"/><ellipse cx="64" cy="56" rx="2.4" ry="3.3"/><ellipse cx="59" cy="67" rx="2.4" ry="3.3"/></g>
      <path d="M48 28 Q42 21 45 16 M53 26 Q55 17 63 14" stroke="#278d4b" stroke-width="4" fill="none" stroke-linecap="round"/>
    `
  ),

  watermelon: buildCircleImage(
    "#e4f6df",
    `
      <path d="M27 67 A34 34 0 0 0 94 67Z" fill="#27894b"/>
      <path d="M34 67 A27 27 0 0 0 87 67Z" fill="#ff7371"/>
      <path d="M30 68 A30 30 0 0 0 91 68" fill="none" stroke="#a8da72" stroke-width="5"/>
      <g fill="#5d3030"><ellipse cx="50" cy="57" rx="2" ry="4"/><ellipse cx="62" cy="51" rx="2" ry="4"/><ellipse cx="73" cy="59" rx="2" ry="4"/></g>
    `
  ),

  lemon: buildCircleImage(
    "#f5f8dc",
    `
      <path d="M34 60 C42 44 55 35 70 38 C82 40 91 51 86 64 C80 78 64 84 49 80 C35 77 28 70 34 60Z" fill="#f2d83d"/>
      <path d="M37 60 C49 48 67 43 82 48" stroke="#fff28a" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M42 44 Q34 36 39 29 Q48 33 49 42" fill="#308d48"/>
    `
  ),

  jowar: buildCircleImage(
    "#fff3d3",
    `
      <path d="M59 86 L59 34 M59 52 C45 42 38 34 36 25 M59 58 C73 47 81 37 84 27" stroke="#5b9e42" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M35 26 Q30 20 34 16 M42 32 Q37 25 42 20 M49 39 Q44 31 49 26 M83 28 Q90 21 87 16 M76 36 Q84 29 80 22 M68 43 Q77 35 73 29" stroke="#d1a62f" stroke-width="5" stroke-linecap="round"/>
      <path d="M59 67 C44 59 35 58 27 62 C36 73 47 76 59 75 M60 73 C74 63 85 62 94 66 C85 78 72 81 60 80" fill="#80c85c"/>
    `
  ),

  vegetableMix: buildCircleImage(
    "#e7f6e2",
    `
      <circle cx="44" cy="65" r="20" fill="#ef514d"/><path d="M43 45 L48 52 L58 49 L53 58 L61 64 L50 64 L43 74 L38 64 L29 64 L36 57 L33 50 L41 52Z" fill="#268747"/>
      <path d="M69 81 C63 68 66 48 76 38 C84 30 91 34 91 45 C92 61 83 75 75 83Z" fill="#328f4b"/><path d="M74 78 Q79 58 87 40" stroke="#b9e796" stroke-width="3" fill="none"/>
      <circle cx="66" cy="43" r="12" fill="#a9d97f"/><circle cx="82" cy="47" r="12" fill="#8fcd69"/><circle cx="73" cy="60" r="14" fill="#c2e79a"/><path d="M60 49 Q73 42 86 52 M63 60 Q74 54 84 62" stroke="#eef9d9" stroke-width="2" fill="none"/>
    `
  ),

  fruitMix: buildCircleImage(
    "#fff2df",
    `
      <circle cx="43" cy="63" r="20" fill="#ef5148"/><path d="M43 42 Q49 32 58 35 Q54 43 45 46" fill="#258648"/><path d="M40 49 Q43 61 42 78" stroke="#ff9c7b" stroke-width="3" fill="none"/>
      <circle cx="78" cy="67" r="19" fill="#f28c27"/><circle cx="72" cy="60" r="5" fill="#ffc45e" opacity=".8"/><path d="M78 48 Q82 38 91 39 Q88 48 80 51" fill="#258648"/>
      <path d="M55 85 C57 69 69 58 83 59 C82 76 71 89 58 91Z" fill="#f2cf42"/>
    `
  ),

  pulseMix: buildCircleImage(
    "#eff6df",
    `
      <path d="M28 70 C42 53 61 40 84 32 C94 29 97 37 88 44 C70 58 49 72 32 77Z" fill="#5cae4c"/>
      <path d="M34 70 Q56 51 85 37" stroke="#c8e994" stroke-width="3" fill="none" stroke-linecap="round"/>
      <g fill="#e2bd68"><circle cx="48" cy="59" r="5"/><circle cx="59" cy="52" r="5"/><circle cx="71" cy="46" r="5"/><circle cx="52" cy="79" r="8"/><circle cx="69" cy="75" r="8"/><circle cx="84" cy="67" r="8"/></g>
      <path d="M57 79 Q65 90 78 86" stroke="#238047" stroke-width="3" fill="none" stroke-linecap="round"/>
    `
  ),

  oilseedMix: buildCircleImage(
    "#fff5d8",
    `
      <circle cx="60" cy="57" r="14" fill="#80521e"/>
      <g fill="#f4c83e"><ellipse cx="60" cy="27" rx="7" ry="14"/><ellipse cx="60" cy="87" rx="7" ry="14"/><ellipse cx="30" cy="57" rx="14" ry="7"/><ellipse cx="90" cy="57" rx="14" ry="7"/><ellipse cx="39" cy="36" rx="7" ry="14" transform="rotate(-45 39 36)"/><ellipse cx="81" cy="78" rx="7" ry="14" transform="rotate(-45 81 78)"/><ellipse cx="81" cy="36" rx="7" ry="14" transform="rotate(45 81 36)"/><ellipse cx="39" cy="78" rx="7" ry="14" transform="rotate(45 39 78)"/></g>
      <path d="M59 72 L59 101 M59 85 Q44 78 37 84 M60 91 Q73 82 82 86" stroke="#39884a" stroke-width="4" fill="none" stroke-linecap="round"/>
    `
  ),

  spiceMix: buildCircleImage(
    "#fff1df",
    `
      <path d="M33 67 C42 46 70 40 87 52 C80 74 57 87 39 81 C32 79 30 73 33 67Z" fill="#e0a122"/>
      <path d="M40 68 Q56 56 79 53 M45 76 Q62 66 78 62" stroke="#ffd56e" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M44 50 C39 37 49 28 60 29 C64 42 57 51 44 50Z" fill="#ca4538"/><path d="M44 49 Q38 42 39 35" stroke="#358549" stroke-width="4" fill="none" stroke-linecap="round"/>
      <circle cx="75" cy="80" r="5" fill="#84502c"/><circle cx="87" cy="75" r="4" fill="#493722"/><circle cx="81" cy="88" r="4" fill="#9a6e35"/>
    `
  ),

  generic: buildCircleImage(
    "#dcfce7",
    `
      <rect x="0" y="84" width="120" height="36" fill="#86efac"/>
      <path d="M60 26 C74 38, 80 52, 76 66 C72 80, 52 84, 44 70 C38 60, 44 40, 60 26 Z" fill="#22c55e"/>
      <path d="M60 32 C56 46, 54 60, 54 74" stroke="#15803d" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M58 48 C68 44, 74 40, 78 34" stroke="#15803d" stroke-width="3" fill="none" stroke-linecap="round"/>
    `
  ),
};

const LOCAL_CROP_PHOTOS = [
  { terms: ["paddy", "rice"], path: "/crops/paddy.webp" },
  { terms: ["wheat"], path: "/crops/wheat.webp" },
  { terms: ["tomato"], path: "/crops/tomato.webp" },
  { terms: ["onion"], path: "/crops/onion.webp" },
  { terms: ["potato"], path: "/crops/potato.webp" },
  { terms: ["chilli", "chili"], path: "/crops/chilli.webp" },
  { terms: ["maize", "corn"], path: "/crops/maize.webp" },
  { terms: ["cotton"], path: "/crops/cotton.webp" },
  { terms: ["banana"], path: "/crops/banana.webp" },
  { terms: ["turmeric"], path: "/crops/turmeric.webp" },
  { terms: ["groundnut", "peanut"], path: "/crops/groundnut.webp" },
  { terms: ["brinjal", "eggplant", "aubergine"], path: "/crops/brinjal.webp" },
  { terms: ["mango"], path: "/crops/mango.webp" },
  { terms: ["apple"], path: "/crops/apple.webp" },
];

function getCropImage(commodity) {
  const value = normalizeText(commodity);

  const localPhoto = LOCAL_CROP_PHOTOS.find(({ terms }) =>
    terms.some((term) => value.includes(term))
  );
  if (localPhoto) return localPhoto.path;

  if (value.includes("bhindi") || value.includes("okra") || value.includes("ladies finger")) {
    return CROP_IMAGES.okra;
  }

  if (value.includes("bitter gourd") || value.includes("bitterguard") || value.includes("karela")) {
    return CROP_IMAGES.bitterGourd;
  }

  if (value.includes("bottle gourd") || value.includes("bottlegourd") || value.includes("lauki")) {
    return CROP_IMAGES.bottleGourd;
  }

  if (value.includes("cabbage")) return CROP_IMAGES.cabbage;
  if (value.includes("beetroot") || value.includes("beet root")) return CROP_IMAGES.beetroot;
  if (value.includes("cauliflower")) return CROP_IMAGES.cauliflower;
  if (value.includes("carrot")) return CROP_IMAGES.carrot;
  if (value.includes("cucumber")) return CROP_IMAGES.cucumber;
  if (value.includes("french bean") || value.includes("frasbean") || value.includes("green bean")) {
    return CROP_IMAGES.beans;
  }
  if (value.includes("pumpkin")) return CROP_IMAGES.pumpkin;

  if (value.includes("orange")) return CROP_IMAGES.orange;
  if (value.includes("grape")) return CROP_IMAGES.grapes;
  if (value.includes("papaya")) return CROP_IMAGES.papaya;
  if (value.includes("watermelon")) return CROP_IMAGES.watermelon;
  if (value.includes("guava")) return CROP_IMAGES.guava;
  if (value.includes("pomegranate")) return CROP_IMAGES.pomegranate;
  if (value.includes("lemon")) return CROP_IMAGES.lemon;

  if (value.includes("jowar") || value.includes("sorghum")) return CROP_IMAGES.jowar;

  if (value.includes("paddy") || value.includes("rice")) {
    return CROP_IMAGES.paddy;
  }

  if (value.includes("tomato")) {
    return CROP_IMAGES.tomato;
  }

  if (value.includes("onion")) {
    return CROP_IMAGES.onion;
  }

  if (value.includes("potato")) {
    return CROP_IMAGES.potato;
  }

  if (
    value.includes("chilli") ||
    value.includes("chili")
  ) {
    return CROP_IMAGES.chilli;
  }

  if (
    value.includes("maize") ||
    value.includes("corn")
  ) {
    return CROP_IMAGES.maize;
  }

  if (value.includes("cotton")) {
    return CROP_IMAGES.cotton;
  }

  if (value.includes("banana")) {
    return CROP_IMAGES.banana;
  }

  if (value.includes("turmeric")) {
    return CROP_IMAGES.turmeric;
  }

  const category = getCropCategory(commodity);

  if (category === "cereals") {
    return CROP_IMAGES.jowar;
  }

  if (category === "pulses") {
    return CROP_IMAGES.pulseMix;
  }

  if (category === "vegetables") {
    return CROP_IMAGES.vegetableMix;
  }

  if (category === "fruits") {
    return CROP_IMAGES.fruitMix;
  }

  if (category === "spices") {
    return CROP_IMAGES.spiceMix;
  }

  if (category === "oilseeds") {
    return CROP_IMAGES.oilseedMix;
  }

  if (category === "fibre") {
    return CROP_IMAGES.cotton;
  }

  return CROP_IMAGES.generic;
}

export default function MarketPricesPage() {
  const language = useLanguage();
  const navigate = useNavigate();

  const [farmer, setFarmer] = useState(null);
  const [location, setLocation] = useState(null);
  const [detectedPlace, setDetectedPlace] =
    useState(null);

  const [prices, setPrices] = useState([]);
  const [priceMeta, setPriceMeta] = useState(null);
  const [priceRequest, setPriceRequest] = useState(null);
  const [priceError, setPriceError] = useState("");
  const [sellingPoints, setSellingPoints] =
    useState([]);
  const [availableStates, setAvailableStates] =
    useState([]);
  const [availableDistricts, setAvailableDistricts] =
    useState([]);
  const [availableMandals, setAvailableMandals] =
    useState([]);

  const [searchText, setSearchText] = useState("");
  const [selectedCategory, setSelectedCategory] =
    useState("all");
  const [selectedState, setSelectedState] =
    useState("");
  const [selectedDistrict, setSelectedDistrict] =
    useState("");
  const [selectedMandal, setSelectedMandal] =
    useState("");
  const [selectedMarket, setSelectedMarket] =
    useState("");
  const [sortMode, setSortMode] =
    useState("latest");
  const [visibleRecordLimit, setVisibleRecordLimit] = useState(60);
  const [featuredPricesExpanded, setFeaturedPricesExpanded] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadingPrices, setLoadingPrices] =
    useState(false);
  const [loadingSellingPoints, setLoadingSellingPoints] =
    useState(false);
  const [detectingLocation, setDetectingLocation] =
    useState(false);
  const [loadingDistricts, setLoadingDistricts] =
    useState(false);
  const [loadingMandals, setLoadingMandals] =
    useState(false);

  const [message, setMessage] = useState(null);

  useEffect(() => {
    initializePage();
  }, []);

  useEffect(() => {
    let active = true;

    fetchLgdRecords("states")
      .then((records) => {
        if (active) {
          setAvailableStates(records);
        }
      })
      .catch((error) => {
        console.error("State list loading error:", error);
      });

    return () => {
      active = false;
    };
  }, []);

  const districts = useMemo(() => {
    if (availableDistricts.length > 0) {
      return availableDistricts.map((district) => district.name);
    }

    return [
      ...new Set(
        prices
          .filter(
            (item) =>
              normalizeText(item.state) ===
              normalizeText(selectedState)
          )
          .map((item) => item.district)
          .filter(Boolean)
      ),
    ].sort((first, second) =>
      first.localeCompare(second)
    );
  }, [availableDistricts, prices, selectedState]);

  const stateChoices = useMemo(
    () => availableStates.length
      ? availableStates.map((state) => state.name)
      : INDIA_STATE_CHOICES,
    [availableStates]
  );

  useEffect(() => {
    let active = true;

    async function loadDistricts() {
      if (!selectedState || availableStates.length === 0) {
        setAvailableDistricts([]);
        setLoadingDistricts(false);
        return;
      }

      const stateRecord = availableStates.find(
        (state) =>
          normalizeText(state.name) === normalizeText(selectedState)
      );

      if (!stateRecord) {
        setAvailableDistricts([]);
        setLoadingDistricts(false);
        return;
      }

      setLoadingDistricts(true);
      setAvailableDistricts([]);

      try {
        const records = await fetchLgdRecords("districts", {
          stateCode: stateRecord.code,
        });

        if (active) {
          setAvailableDistricts(records);
        }
      } catch (error) {
        console.error("District list loading error:", error);
      } finally {
        if (active) {
          setLoadingDistricts(false);
        }
      }
    }

    loadDistricts();

    return () => {
      active = false;
    };
  }, [availableStates, selectedState]);

  useEffect(() => {
    let active = true;

    async function loadMandals() {
      if (!selectedDistrict || availableDistricts.length === 0) {
        setAvailableMandals([]);
        setLoadingMandals(false);
        return;
      }

      const districtRecord = availableDistricts.find(
        (district) =>
          normalizeDistrictKey(district.name) ===
          normalizeDistrictKey(selectedDistrict)
      );

      if (!districtRecord) {
        setAvailableMandals([]);
        setLoadingMandals(false);
        return;
      }

      setLoadingMandals(true);
      setAvailableMandals([]);

      try {
        const records = await fetchLgdRecords("subdistricts", {
          districtCode: districtRecord.code,
        });

        if (active) {
          setAvailableMandals(records);
        }
      } catch (error) {
        console.error("Mandal list loading error:", error);
      } finally {
        if (active) {
          setLoadingMandals(false);
        }
      }
    }

    loadMandals();

    return () => {
      active = false;
    };
  }, [availableDistricts, selectedDistrict]);

  const mandalOptions = useMemo(() => {
    return availableMandals.map((mandal) => mandal.name);
  }, [availableMandals]);

  const selectedDistrictOption = availableDistricts.find(
    (district) =>
      normalizeDistrictKey(district.name) ===
      normalizeDistrictKey(selectedDistrict)
  )?.name;

  const markets = useMemo(() => {
    return [
      ...new Set(
        prices
          .filter(
            (item) =>
              !selectedDistrict ||
              normalizeDistrictKey(item.district) ===
                normalizeDistrictKey(selectedDistrict)
          )
          .map((item) => item.market)
          .filter(Boolean)
      ),
    ].sort((first, second) =>
      first.localeCompare(second)
    );
  }, [prices, selectedDistrict]);

  const cropSearchOptions = useMemo(
    () =>
      [
        ...new Set(
          prices
            .map((item) => item.commodity)
            .filter(Boolean)
        ),
      ].sort((first, second) => first.localeCompare(second)),
    [prices]
  );

  const visiblePrices = prices;
  const visibleMarkets = markets;

  const filteredPrices = useMemo(() => {
    const cropSearchTerms = getCropSearchTerms(searchText);

    const results = visiblePrices.filter((item) => {
      if (
        selectedCategory !== "all" &&
        item.category !== selectedCategory
      ) {
        return false;
      }

      if (
        selectedDistrict &&
        normalizeDistrictKey(item.district) !==
          normalizeDistrictKey(selectedDistrict)
      ) {
        return false;
      }

      if (
        selectedMandal &&
        normalizeText(item.mandal) !== normalizeText(selectedMandal)
      ) {
        return false;
      }

      if (
        selectedMarket &&
        normalizeText(item.market) !==
          normalizeText(selectedMarket)
      ) {
        return false;
      }

      if (cropSearchTerms.length === 0) {
        return true;
      }

      const searchableText = [
        item.commodity,
        item.variety,
        item.market,
        item.district,
        item.state,
        item.mandal,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return cropSearchTerms.some((crop) =>
        searchableText.includes(crop)
      );
    });

    return [...results].sort((first, second) => {
      if (sortMode === "highest") {
        return second.modalPrice - first.modalPrice;
      }

      if (sortMode === "lowest") {
        return first.modalPrice - second.modalPrice;
      }

      if (sortMode === "crop") {
        return first.commodity.localeCompare(
          second.commodity
        );
      }

      return (
        second.arrivalTimestamp -
        first.arrivalTimestamp
      );
    });
  }, [
    visiblePrices,
    searchText,
    selectedCategory,
    selectedDistrict,
    selectedMandal,
    selectedMarket,
    sortMode,
  ]);

  const featuredCropPrices = useMemo(() => {
    const cropTerms = getCropSearchTerms(farmer?.mainCrop || "");
    if (!cropTerms.length) return [];
    return prices.filter((item) =>
      cropTerms.some((term) => normalizeText(item.commodity).includes(term))
    );
  }, [farmer?.mainCrop, prices]);

  const groupedCropSummary = useMemo(() => {
    const cropMap = new Map();

    filteredPrices.forEach((item) => {
      const key = normalizeText(item.commodity);

      if (!cropMap.has(key)) {
        cropMap.set(key, {
          commodity: item.commodity,
          category: item.category,
          records: [],
        });
      }

      cropMap.get(key).records.push(item);
    });

    return Array.from(cropMap.values())
      .map((group) => {
        const records = group.records;

        const highest = records.reduce(
          (best, item) =>
            item.modalPrice > best.modalPrice
              ? item
              : best,
          records[0]
        );

        const lowest = records.reduce(
          (best, item) =>
            item.modalPrice < best.modalPrice
              ? item
              : best,
          records[0]
        );

        const average =
          records.reduce(
            (sum, item) => sum + item.modalPrice,
            0
          ) / records.length;

        return {
          ...group,
          image: getCropImage(group.commodity),
          icon:
            CATEGORY_ICONS[group.category] || "🌱",
          highest,
          lowest,
          average,
          marketsCount: new Set(
            records.map((item) => item.market)
          ).size,
        };
      })
      .sort((first, second) =>
        first.commodity.localeCompare(second.commodity)
      );
  }, [filteredPrices]);

  const overallStatistics = useMemo(() => {
    const allModalPrices = filteredPrices
      .map((item) => item.modalPrice)
      .filter((value) => value > 0);

    const uniqueCrops = new Set(
      filteredPrices.map((item) =>
        normalizeText(item.commodity)
      )
    ).size;

    const uniqueMarkets = new Set(
      filteredPrices.map((item) =>
        normalizeText(item.market)
      )
    ).size;

    const averagePrice =
      allModalPrices.length > 0
        ? allModalPrices.reduce(
            (sum, value) => sum + value,
            0
          ) / allModalPrices.length
        : 0;

    return {
      crops: uniqueCrops,
      markets: uniqueMarkets,
      averagePrice,
    };
  }, [filteredPrices]);

  function showMessage(type, text) {
    setMessage({ type, text });

    window.setTimeout(() => {
      setMessage(null);
    }, 6000);
  }

  async function initializePage() {
    setLoading(true);

    try {
      const currentUser = await getAuthUser();

      if (!currentUser) {
        navigate("/login", { replace: true });
        return;
      }

      const [userSnapshot, farmerSnapshot] =
        await Promise.all([
          get(ref(database, `users/${currentUser.uid}`)),
          get(ref(database, `farmers/${currentUser.uid}`)),
        ]);

      if (
        !userSnapshot.exists() ||
        userSnapshot.val().role !== "farmer"
      ) {
        navigate("/role-selection", {
          replace: true,
        });
        return;
      }

      const farmerProfile = {
        uid: currentUser.uid,
        ...userSnapshot.val(),
        ...(farmerSnapshot.exists()
          ? farmerSnapshot.val()
          : {}),
        role: userSnapshot.val().role,
      };

      setFarmer(farmerProfile);

      await detectLocationAndLoadData();
    } catch (error) {
      console.error(
        "Market page initialization error:",
        error
      );

      showMessage(
        "error",
        t("marketInfoUnavailable", {}, language)
      );

      setLoading(false);
    }
  }

  async function detectLocationAndLoadData(options = {}) {
    setDetectedPlace(null);
    setLocation(null);
    setPrices([]);
    setSelectedDistrict("");
    setSelectedMandal("");
    setSelectedMarket("");
    setLoading(false);

    setDetectingLocation(true);
    setMessage(null);

    try {
      const currentLocation = await getCurrentLocation({
        enableHighAccuracy: true,
        timeout: 20000,
        forceRefresh: options.forceRefresh === true,
      });

      if (
        !Number.isFinite(currentLocation.latitude) ||
        !Number.isFinite(currentLocation.longitude) ||
        currentLocation.latitude < -90 ||
        currentLocation.latitude > 90 ||
        currentLocation.longitude < -180 ||
        currentLocation.longitude > 180
      ) {
        showMessage("warning", t("exactLocationFallback", {}, language));
        return;
      }

      setLocation(currentLocation);

      try {
        const place = await reverseGeocodeLocation(currentLocation);
        setDetectedPlace(place);

        if (place.state) {
          setSelectedState(place.state);
          setSelectedDistrict(place.district);
          loadAllCropPrices({
            state: place.state,
            district: place.district,
          });
        } else {
          showMessage("warning", t("exactLocationFallback", {}, language));
        }

        loadNearbySellingPoints(currentLocation);
      } catch (error) {
        console.error("Detected location loading error:", error);
        showMessage("warning", t("exactLocationFallback", {}, language));
        loadNearbySellingPoints(currentLocation);
      }
    } catch (error) {
      const errorKey = getLocationErrorTranslationKey(error);
      const messageKey = errorKey === "locationAccessNeeded"
        ? "locationPermissionNearby"
        : errorKey;
      showMessage(
        "warning",
        ["LOW_ACCURACY", "LOCATION_DISABLED"].includes(error?.code)
          ? error.message
          : t(messageKey, {}, language)
      );
    } finally {
      setDetectingLocation(false);
    }
  }

  async function reverseGeocodeLocation({
    latitude,
    longitude,
  }) {
    const result = await reverseGeocodeCoordinates({ latitude, longitude });

    if (result?.countryCode !== "IN") {
      throw new Error("Location is outside India or could not be identified.");
    }

    const administrative =
      result?.localityInfo?.administrative || [];

    function findAdministrative(keywords) {
      return (
        administrative.find((item) => {
          const value = normalizeText(
            `${item.name || ""} ${
              item.description || ""
            }`
          );

          return keywords.some((keyword) =>
            value.includes(keyword)
          );
        })?.name || ""
      );
    }

    return {
      village: result.locality || result.city || "",

      mandal:
        findAdministrative([
          "mandal",
          "taluk",
          "tehsil",
          "subdistrict",
          "sub-district",
        ]) || "",

      district: normalizeDistrictName(findAdministrative(["district"])),

      state: normalizeStateName(
        result.principalSubdivision ||
          findAdministrative(["state"]) || ""
      ),

      postcode: result.postcode || "",
      country: result.countryName || "",
    };
  }

  async function loadAllCropPrices({
    state,
    district,
    forceRefresh = false,
  }) {
    if (!state) return;

    const normalizedState = normalizeStateName(state);
    const normalizedDistrict = normalizeDistrictName(district);
    const request = { state: normalizedState, district: normalizedDistrict };
    setPriceRequest(request);
    setPriceError("");
    setPriceMeta(null);
    setSelectedState(normalizedState);
    setPrices([]);
    setLoadingPrices(true);

    try {
      const result = await fetchGovernmentMarketPrices({
        state: normalizedState,
        district: normalizedDistrict,
        forceRefresh,
      });
      const records = result.records;
      setPriceMeta({ retrievedAt: result.retrievedAt, source: result.source });

      const preparedRecords = records
        .map((record, index) => {
          const commodity =
            record.commodity ||
            record.Commodity ||
            "";

          return {
            id: [
              record.market,
              record.commodity,
              record.variety,
              record.arrival_date,
              index,
            ].join("-"),

            state:
              record.state ||
              record.State ||
              normalizedState,

            district:
              record.district ||
              record.District ||
              "",

            market:
              record.market ||
              record.Market ||
              "",

            commodity,

            variety:
              record.variety ||
              record.Variety ||
              "",

            mandal:
              record.mandal ||
              record.subdistrict ||
              record.sub_district ||
              record.taluk ||
              "",

            unit:
              record.unit ||
              record.price_unit ||
              "",

            grade:
              record.grade ||
              record.Grade ||
              "",

            arrivalDate:
              record.arrival_date ||
              record.Arrival_Date ||
              "",

            arrivalTimestamp:
              parseArrivalDate(
                record.arrival_date ||
                  record.Arrival_Date
              ),

            minimumPrice: numberValue(
              record.min_price ||
                record.Min_Price
            ),

            maximumPrice: numberValue(
              record.max_price ||
                record.Max_Price
            ),

            modalPrice: numberValue(
              record.modal_price ||
                record.Modal_Price
            ),

            category:
              getCropCategory(commodity),

            image: getCropImage(commodity),
            icon:
              CATEGORY_ICONS[
                getCropCategory(commodity)
              ] || "🌱",
            source: "AGMARKNET / data.gov.in",
          };
        })
        .filter(
          (record) =>
            record.commodity && record.market &&
            record.modalPrice > 0
        );

      const deduplicated = Array.from(
        new Map(
          preparedRecords.map((record) => [
            [
              normalizeText(record.state),
              normalizeText(record.district),
              normalizeText(record.market),
              normalizeText(record.commodity),
              normalizeText(record.variety),
              record.arrivalDate,
            ].join("|"),
            record,
          ])
        ).values()
      );

      setPrices(deduplicated);
      setSelectedDistrict(normalizedDistrict);

      setSelectedMarket("");

      if (deduplicated.length === 0) {
        showMessage(
          "info",
          t("noCurrentMandiPrices", {}, language)
        );
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        console.error("Government price request failed:", error);
      }

      setPrices([]);
      setPriceError(getGovernmentMarketPriceErrorMessage(error));
    } finally {
      setLoadingPrices(false);
    }
  }

  async function loadNearbySellingPoints(
    currentLocation = location
  ) {
    if (!currentLocation) {
      showMessage(
        "warning",
        t("locationRequiredSelling", {}, language)
      );
      return;
    }

    setLoadingSellingPoints(true);

    try {
      const { latitude, longitude } =
        currentLocation;

      const overpassQuery = `
[out:json][timeout:35];
(
  node["amenity"="marketplace"](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
  way["amenity"="marketplace"](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
  relation["amenity"="marketplace"](around:${SELLING_POINT_RADIUS},${latitude},${longitude});

  node["name"~"mandi|market yard|agriculture market|agricultural market|rythu bazar|farmer market",i](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
  way["name"~"mandi|market yard|agriculture market|agricultural market|rythu bazar|farmer market",i](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
  relation["name"~"mandi|market yard|agriculture market|agricultural market|rythu bazar|farmer market",i](around:${SELLING_POINT_RADIUS},${latitude},${longitude});

  node["industrial"="rice_mill"](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
  way["industrial"="rice_mill"](around:${SELLING_POINT_RADIUS},${latitude},${longitude});

  node["name"~"rice mill|flour mill|oil mill|cotton mill|dal mill|seed market",i](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
  way["name"~"rice mill|flour mill|oil mill|cotton mill|dal mill|seed market",i](around:${SELLING_POINT_RADIUS},${latitude},${longitude});
);
out center tags;
`;

      const response = await fetch(
        "https://overpass-api.de/api/interpreter",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/x-www-form-urlencoded;charset=UTF-8",
          },
          body: `data=${encodeURIComponent(
            overpassQuery
          )}`,
        }
      );

      if (!response.ok) {
        throw new Error(
          "Nearby market search failed."
        );
      }

      const result = await response.json();

      const prepared = (result?.elements || [])
        .map((element) => {
          const pointLatitude =
            element.lat ||
            element.center?.lat;

          const pointLongitude =
            element.lon ||
            element.center?.lon;

          if (!pointLatitude || !pointLongitude) {
            return null;
          }

          const tags = element.tags || {};
          const name =
            tags.name ||
            tags["name:en"] ||
            t("nearbySellingPlaces", {}, language);

          const distance = calculateDistance(
            latitude,
            longitude,
            pointLatitude,
            pointLongitude
          );

          let type = "Market";

          const combinedName =
            normalizeText(name);

          if (
            combinedName.includes("rice mill")
          ) {
            type = "Rice Mill";
          } else if (
            combinedName.includes("oil mill")
          ) {
            type = "Oil Mill";
          } else if (
            combinedName.includes("cotton mill")
          ) {
            type = "Cotton Mill";
          } else if (
            combinedName.includes("dal mill")
          ) {
            type = "Dal Mill";
          } else if (
            combinedName.includes("flour mill")
          ) {
            type = "Flour Mill";
          } else if (
            tags.amenity === "marketplace"
          ) {
            type = "Marketplace";
          }

          const address = [
            tags["addr:street"],
            tags["addr:place"],
            tags["addr:city"],
            tags["addr:district"],
          ]
            .filter(Boolean)
            .join(", ");

          return {
            id: `${element.type}-${element.id}`,
            name,
            type,
            latitude: pointLatitude,
            longitude: pointLongitude,
            distance,
            address,
            phone:
              tags.phone ||
              tags["contact:phone"] ||
              "",
            openingHours:
              tags.opening_hours || "",
          };
        })
        .filter(Boolean)
        .sort(
          (first, second) =>
            first.distance - second.distance
        )
        .slice(0, 25);

      setSellingPoints(prepared);

      if (prepared.length === 0) {
        showMessage(
          "info",
          t("noMappedSellingPoints", {}, language)
        );
      }
    } catch (error) {
      console.error(
        "Nearby selling points error:",
        error
      );

      setSellingPoints([]);

      showMessage(
        "warning",
        t("nearbySellingUnavailable", {}, language)
      );
    } finally {
      setLoadingSellingPoints(false);
    }
  }

  function openDirections(point) {
    window.open(
      `https://www.google.com/maps/dir/?api=1&destination=${point.latitude},${point.longitude}`,
      "_blank",
      "noopener,noreferrer"
    );
  }

  function openGeneralMapSearch() {
    const crop =
      farmer?.mainCrop || "crop";
    const area =
      detectedPlace?.district ||
      farmer?.district ||
      "";

    const searchQuery =
      `${crop} mandi agriculture market mill ${area}`.trim();

    window.open(
      `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
        searchQuery
      )}`,
      "_blank",
      "noopener,noreferrer"
    );
  }

  function getSellingAdvice(summary) {
    if (!summary?.highest) {
      return {
        label: t("cropPriceSummaryUnavailable", {}, language),
        className:
          "bg-gray-100 text-gray-700",
      };
    }

    const difference =
      summary.highest.modalPrice -
      summary.average;

    const differencePercentage =
      summary.average > 0
        ? (difference / summary.average) * 100
        : 0;

    if (differencePercentage >= 8) {
      return {
        label: t("goodMarketPrice", {}, language),
        className:
          "bg-green-100 text-green-700",
      };
    }

    if (differencePercentage >= 3) {
      return {
        label: t("compareMarkets", {}, language),
        className:
          "bg-yellow-100 text-yellow-800",
      };
    }

    return {
      label: t("checkBeforeSelling", {}, language),
      className:
        "bg-blue-100 text-blue-700",
    };
  }

  const categories = [
    {
      value: "all",
      labelKey: "categoryAllCrops",
      icon: "🛍️",
    },
    {
      value: "cereals",
      labelKey: "categoryGrains",
      icon: "🌾",
    },
    {
      value: "pulses",
      labelKey: "categoryPulses",
      icon: "🫘",
    },
    {
      value: "vegetables",
      labelKey: "categoryVegetables",
      icon: "🥬",
    },
    {
      value: "fruits",
      labelKey: "categoryFruits",
      icon: "🍎",
    },
    {
      value: "spices",
      labelKey: "categorySpices",
      icon: "🌶️",
    },
    {
      value: "oilseeds",
      labelKey: "categoryOilseeds",
      icon: "🌻",
    },
    {
      value: "fibre",
      labelKey: "categoryFibre",
      icon: "🧶",
    },
  ];

  if (loading) {
    return (
      <div className="market-prices-page market-prices-loading min-h-screen flex items-center justify-center p-4">
        <div className="market-prices-loading-card rounded-2xl p-7 text-center">
          <div className="text-5xl">📈</div>

          <h1 className="text-xl font-bold text-green-900 mt-4">
            {detectingLocation
              ? t("detectingMarketArea", {}, language)
              : t("marketLoading", {}, language)}
          </h1>
        </div>
      </div>
    );
  }

  return (
    <div className="market-prices-page min-h-screen p-3 sm:p-5">
      <div className="market-prices-shell mx-auto max-w-7xl">
        <StatusMessage
          message={message}
          onClose={() => setMessage(null)}
        />

        <header className="market-prices-hero relative isolate overflow-hidden rounded-2xl p-5 text-white shadow sm:rounded-3xl sm:p-7">
          <button
            type="button"
            onClick={() =>
              navigate("/dashboard")
            }
            className="market-prices-back font-semibold"
          >
            {t("dashboardLink", {}, language)}
          </button>

          <div className="flex flex-col gap-4 mt-3">
            <div>
              <h1 className="text-3xl font-bold">
                {t("localCropPricesTitle", {}, language)}
              </h1>

              <p className="text-green-100 mt-1">
                {t("marketPageIntro", {}, language)}
              </p>
            </div>

            <button
              type="button"
              disabled={detectingLocation}
              onClick={() =>
                detectLocationAndLoadData(
                  { forceRefresh: true }
                )
              }
              className="market-prices-refresh self-start rounded-xl px-4 py-2.5 font-semibold disabled:opacity-60"
            >
              {detectingLocation
                ? t("detecting", {}, language)
                : t("refreshLocation", {}, language)}
            </button>
          </div>

          <div className="market-prices-location mt-4 rounded-xl p-3 text-sm">
            📍{" "}
            {detectedPlace
              ? [detectedPlace.mandal, detectedPlace.district, detectedPlace.state]
                  .filter(Boolean)
                  .join(", ") || t("locationNotAvailable", {}, language)
              : location
                ? t("locationCoordinatesOnly", {}, language)
              : detectingLocation
                ? t("detectingMarketArea", {}, language)
                : t("locationNotDetected", {}, language)}
            {location?.accuracy != null && (
              <span className="mt-1 block text-xs text-green-100">
                Live device location · GPS accuracy about ±{Math.round(location.accuracy)} m
              </span>
            )}
          </div>
        </header>

        <section className="market-prices-stats mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <article className="market-prices-stat rounded-xl border p-3 sm:p-4">
            <p className="text-sm text-gray-500">
              {t("cropCount", {}, language)}
            </p>

            <p className="text-2xl font-bold text-green-800 mt-2">
              {overallStatistics.crops}
            </p>
          </article>

          <article className="market-prices-stat rounded-xl border p-3 sm:p-4">
            <p className="text-sm text-gray-500">
              {t("marketCount", {}, language)}
            </p>

            <p className="text-2xl font-bold text-blue-800 mt-2">
              {overallStatistics.markets}
            </p>
          </article>

          <article className="market-prices-stat rounded-xl border p-3 sm:p-4">
            <p className="text-sm text-gray-500">
              {t("priceRecords", {}, language)}
            </p>

            <p className="text-2xl font-bold text-purple-800 mt-2">
              {filteredPrices.length}
            </p>
          </article>

          <article className="market-prices-stat rounded-xl border p-3 sm:p-4">
            <p className="text-sm text-gray-500">
              {t("averagePrice", {}, language)}
            </p>

            <p className="text-lg font-bold text-orange-800 mt-2">
              {formatCurrency(
                overallStatistics.averagePrice
              )}
            </p>

            <p className="text-xs text-gray-500">
              {t("perQuintal", {}, language)}
            </p>
          </article>
        </section>

        {farmer?.mainCrop && (
          <section className="market-prices-featured mt-4 rounded-2xl border p-3 sm:p-4">
            <div className="flex items-center gap-3">
              <img
                src={getCropImage(farmer.mainCrop)}
                alt={farmer.mainCrop}
                loading="lazy"
                decoding="async"
                className="market-prices-featured-image h-14 w-14 rounded-xl border object-cover"
              />

              <div className="flex-1">
                <p className="text-sm text-amber-800">
                  {t("yourMainCrop", {}, language)}
                </p>

                <h2 className="mt-1 text-xl font-bold text-amber-950">
                  {farmer.mainCrop}
                </h2>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setFeaturedPricesExpanded((expanded) => !expanded);
              }}
              aria-expanded={featuredPricesExpanded}
              className="market-prices-featured-toggle mt-3 rounded-lg px-4 py-2 font-semibold"
            >
              {featuredPricesExpanded ? "Hide Prices" : t("showPrices", {}, language)}
            </button>
            {featuredPricesExpanded && (
              <div className="market-prices-featured-results mt-3 rounded-lg border p-3" aria-live="polite">
                {featuredCropPrices.length ? (
                  <>
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <p className="font-semibold text-green-900">{featuredCropPrices.length} {t("recordCount", {}, language)}</p>
                      <p className="text-sm text-gray-600">{new Set(featuredCropPrices.map((item) => item.market)).size} {t("marketCountLower", {}, language)}</p>
                    </div>
                    <div className="mt-2 grid max-h-72 gap-2 overflow-y-auto sm:grid-cols-2 lg:grid-cols-3">
                      {featuredCropPrices.map((item) => (
                        <div key={item.id} className="rounded-lg bg-green-50 px-3 py-2 text-sm">
                          <p className="font-semibold text-gray-900">{item.market}</p>
                          <p className="text-gray-600">{item.district}{item.arrivalDate ? ` · ${item.arrivalDate}` : ""}</p>
                          <p className="mt-1 font-bold text-green-800">{formatCurrency(item.modalPrice)} <span className="font-normal text-gray-600">/ quintal</span></p>
                        </div>
                      ))}
                    </div>
                  </>
                ) : <p className="text-sm text-gray-600">{t("noCurrentPricesForCrop", { crop: farmer.mainCrop }, language)}</p>}
              </div>
            )}
          </section>
        )}

        <section className="market-prices-filter-panel mt-4 rounded-2xl border p-3 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-semibold text-gray-800">
                {t("govtMandiPrices", {}, language)}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {t("marketDataNotice", {}, language)}
              </p>
            </div>
          </div>

          <label
            htmlFor="crop-price-search"
            className="font-semibold text-gray-800"
          >
            {t("searchAnyCrop", {}, language)}
          </label>

          <input
            id="crop-price-search"
            type="search"
            list="crop-price-options"
            value={searchText}
            onChange={(event) =>
              setSearchText(event.target.value)
            }
            placeholder={t("cropSearchPlaceholder", {}, language)}
            className="market-prices-search mt-2 w-full rounded-xl border px-4 py-3 outline-none"
          />
          <datalist id="crop-price-options">
            {cropSearchOptions.map((cropName) => (
              <option key={cropName} value={cropName} />
            ))}
          </datalist>

          <div className="market-prices-categories mt-4 flex gap-2 overflow-x-auto pb-1">
            {categories.map((category) => (
              <button
                type="button"
                key={category.value}
                onClick={() =>
                  setSelectedCategory(category.value)
                }
                className={`shrink-0 px-4 py-2 rounded-full text-sm font-semibold ${
                  selectedCategory === category.value
                    ? "bg-green-700 text-white"
                    : "bg-green-50 text-green-800 border border-green-200"
                }`}
              >
                {category.icon} {t(category.labelKey, {}, language)}
              </button>
            ))}
          </div>

          <div className="grid gap-3 mt-4 sm:grid-cols-2">
            <label className="grid gap-1 text-sm font-medium text-gray-700">
              {t("marketStateLabel", {}, language)}
              <select
                value={selectedState}
                onChange={(event) => {
                  const nextState = event.target.value;
                  setSelectedState(nextState);
                  setSelectedDistrict("");
                  setSelectedMarket("");
                  setSelectedMandal("");
                  if (nextState) {
                    loadAllCropPrices({ state: nextState, district: "" });
                  } else {
                    setPrices([]);
                  }
                }}
                className="border border-gray-300 rounded-xl px-4 py-3 bg-white"
              >
                <option value="">{t("marketSelectState", {}, language)}</option>
                {stateChoices.map((state) => (
                  <option key={state} value={state}>
                    {state}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-1 text-sm font-medium text-gray-700">
              {t("marketDistrictLabel", {}, language)}
              <select
                value={selectedDistrictOption || selectedDistrict}
                onChange={(event) => {
                  const nextDistrict = event.target.value;
                  setSelectedDistrict(nextDistrict);
                  setSelectedMarket("");
                  setSelectedMandal("");
                  loadAllCropPrices({
                    state: selectedState,
                    district: nextDistrict,
                  });
                }}
                disabled={
                  !selectedState ||
                  loadingDistricts ||
                  districts.length === 0
                }
                className="border border-gray-300 rounded-xl px-4 py-3 bg-white disabled:bg-gray-100"
              >
                <option value="">
                  {loadingDistricts
                    ? t("marketLoadingDistricts", {}, language)
                    : t("allDistricts", {}, language)}
                </option>
                {districts.map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-1 text-sm font-medium text-gray-700">
              {t("marketMandalLabel", {}, language)}
              <select
                value={selectedMandal}
                onChange={(event) => setSelectedMandal(event.target.value)}
                disabled={loadingMandals || (!mandalOptions.length && !selectedDistrict)}
                className="border border-gray-300 rounded-xl px-4 py-3 bg-white disabled:bg-gray-100"
              >
                <option value="">
                  {loadingMandals
                    ? t("marketLoadingMandals", {}, language)
                    : selectedDistrict
                      ? t("marketAllMandals", {}, language)
                      : t("marketSelectDistrictFirst", {}, language)}
                </option>
                {mandalOptions.map((mandal) => (
                  <option key={mandal} value={mandal}>
                    {mandal}
                  </option>
                ))}
              </select>
              <span className="text-xs font-normal text-gray-500">
                {mandalOptions.length
                  ? t("marketMandalsListed", { count: mandalOptions.length }, language)
                  : t("marketMandalListSelectDistrict", {}, language)}
              </span>
              {selectedMandal && (
                <span className="text-xs font-normal text-amber-800">
                  {t("mandalPriceDataUnavailable", {}, language)}
                </span>
              )}
            </label>

            <select
              value={selectedMarket}
              onChange={(event) =>
                setSelectedMarket(
                  event.target.value
                )
              }
              className="border border-gray-300 rounded-xl px-4 py-3"
            >
              <option value="">{t("allMarkets", {}, language)}</option>

              {visibleMarkets.map((market) => (
                <option
                  key={market}
                  value={market}
                >
                  {market}
                </option>
              ))}
            </select>

            <select
              value={sortMode}
              onChange={(event) =>
                setSortMode(event.target.value)
              }
              className="border border-gray-300 rounded-xl px-4 py-3"
            >
              <option value="latest">
                {t("latestRecords", {}, language)}
              </option>
              <option value="highest">
                {t("highestPrice", {}, language)}
              </option>
              <option value="lowest">
                {t("lowestPrice", {}, language)}
              </option>
              <option value="crop">
                {t("cropNameSort", {}, language)}
              </option>
            </select>
          </div>
        </section>

        {(priceError || priceMeta) && (
          <section
            className={`market-prices-notice mt-4 rounded-xl border p-4 ${
              priceError
                ? "border-amber-300 bg-amber-50 text-amber-950"
                : priceMeta.source === "cache"
                  ? "border-amber-300 bg-amber-50 text-amber-950"
                  : "border-green-200 bg-green-50 text-green-950"
            }`}
            role={priceError ? "alert" : "status"}
          >
            {priceError ? (
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p>{priceError}</p>
                <button
                  type="button"
                  disabled={loadingPrices || !priceRequest}
                  onClick={() =>
                    priceRequest &&
                    loadAllCropPrices({ ...priceRequest, forceRefresh: true })
                  }
                  className="rounded-lg bg-amber-800 px-4 py-2 font-semibold text-white disabled:opacity-50"
                >
                  {loadingPrices ? "Retrying..." : "Retry"}
                </button>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p>
                  {priceMeta.source === "cache"
                    ? "Showing recently cached government mandi prices. "
                    : "Government data retrieved. "}
                  Last updated: {new Date(priceMeta.retrievedAt).toLocaleString("en-IN", {
                    dateStyle: "medium",
                    timeStyle: "short",
                  })}
                  {priceMeta.source === "cache" && " (cached, not live)"}
                </p>
                {priceMeta.source === "cache" && (
                  <button
                    type="button"
                    disabled={loadingPrices || !priceRequest}
                    onClick={() =>
                      priceRequest &&
                      loadAllCropPrices({ ...priceRequest, forceRefresh: true })
                    }
                    className="rounded-lg border border-amber-800 px-4 py-2 font-semibold text-amber-950 disabled:opacity-50"
                  >
                    {loadingPrices ? "Retrying..." : "Retry live data"}
                  </button>
                )}
              </div>
            )}
          </section>
        )}

        <section className="market-prices-section market-prices-summary mt-5">
          <div className="flex items-center justify-between gap-3 mb-3">
            <h2 className="text-xl font-bold text-green-900">
              {t("cropPriceSummary", {}, language)}
            </h2>

            {loadingPrices && (
              <p className="text-sm text-gray-500">
                {t("loadingPrices", {}, language)}
              </p>
            )}
          </div>

          {groupedCropSummary.length === 0 ? (
            <div className="market-prices-empty rounded-2xl border p-6 text-center">
              <p className="text-gray-600">
                {t("noCropPricesForFilters", {}, language)}
              </p>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {groupedCropSummary.map((summary) => {
                const advice =
                  getSellingAdvice(summary);

                return (
                  <article
                    key={summary.commodity}
                    className="market-prices-card market-price-summary-card rounded-xl border p-3"
                  >
                    <div className="market-price-card-header market-price-summary-header flex items-start gap-3">
                      <img
                        src={summary.image}
                        alt={summary.commodity}
                        loading="lazy"
                        decoding="async"
                        className="market-prices-crop-image h-16 w-16 rounded-xl border object-cover"
                      />

                      <div className="market-price-summary-copy min-w-0 flex-1">
                        <div className="market-price-summary-title-row flex items-start gap-2">
                          <h3 title={summary.commodity} className="market-price-summary-title min-w-0 text-lg font-bold text-green-900">
                            {summary.commodity}
                          </h3>

                          <span className="shrink-0 text-sm">
                            {summary.icon}
                          </span>
                        </div>

                        <span className={`market-price-summary-advice inline-flex ${advice.className} rounded-full px-2.5 py-1 text-xs font-semibold`}>
                          {advice.label}
                        </span>

                        <p className="market-price-summary-count mt-1 text-sm text-gray-500">
                          {summary.records.length} {t("recordCount", {}, language)} •{" "}
                          {summary.marketsCount} {t("marketCountLower", {}, language)}
                        </p>
                      </div>
                    </div>

                    <div className="market-prices-summary-values mt-3 grid grid-cols-2 gap-2">
                      <div className="market-prices-value-tile market-prices-value-tile--high rounded-xl p-3">
                        <p className="text-xs text-gray-500">
                          {t("highest", {}, language)}
                        </p>
                        <p className="font-bold text-green-800 mt-1">
                          {formatCurrency(
                            summary.highest.modalPrice
                          )}
                        </p>
                        <p title={summary.highest.market} className="market-price-summary-market mt-1 text-xs text-gray-600">
                          {summary.highest.market}
                        </p>
                      </div>

                      <div className="market-prices-value-tile market-prices-value-tile--low rounded-xl p-3">
                        <p className="text-xs text-gray-500">
                          {t("lowest", {}, language)}
                        </p>
                        <p className="font-bold text-red-700 mt-1">
                          {formatCurrency(
                            summary.lowest.modalPrice
                          )}
                        </p>
                        <p title={summary.lowest.market} className="market-price-summary-market mt-1 text-xs text-gray-600">
                          {summary.lowest.market}
                        </p>
                      </div>

                      <div className="market-prices-value-tile market-prices-value-tile--average rounded-xl p-3">
                        <p className="text-xs text-gray-500">
                          {t("averageLabel", {}, language)}
                        </p>
                        <p className="font-bold text-blue-700 mt-1">
                          {formatCurrency(
                            summary.average
                          )}
                        </p>
                      </div>

                      <div className="market-prices-value-tile market-prices-value-tile--best rounded-xl p-3">
                        <p className="text-xs text-gray-500">
                          {t("bestPlace", {}, language)}
                        </p>
                        <p title={summary.highest.market} className="market-price-summary-best mt-1 text-sm font-bold text-yellow-700">
                          {summary.highest.market}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setSearchText(summary.commodity);
                        setSelectedCategory("all");
                      }}
                      className="market-prices-primary-action mt-3 w-full rounded-lg py-2 font-semibold"
                    >
                      {t("viewCommodityDetails", { crop: summary.commodity }, language)}
                    </button>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        <section className="market-prices-section market-prices-records mt-6">
          <div className="flex items-center justify-between gap-3 mb-3">
            <h2 className="text-xl font-bold text-green-900">
              {t("mandiPriceDetails", {}, language)}
            </h2>

            {loadingPrices && (
              <p className="text-sm text-gray-500">
                {t("refreshing", {}, language)}
              </p>
            )}
          </div>

          {filteredPrices.length === 0 ? (
            <div className="market-prices-empty rounded-2xl border p-6 text-center">
              <p className="text-gray-600">
                {t("noMarketRecords", {}, language)}
              </p>
            </div>
          ) : (
            <div className="grid gap-3 xl:grid-cols-2">
              {filteredPrices.slice(0, visibleRecordLimit).map((item) => (
                <article
                  key={item.id}
                  className="market-prices-card market-price-record-card rounded-xl border p-3"
                >
                  <div className="market-price-card-header market-price-record-header flex items-start gap-3">
                    <img
                      src={item.image}
                      alt={item.commodity}
                      loading="lazy"
                      decoding="async"
                      className="market-prices-crop-image h-14 w-14 rounded-xl border object-cover"
                    />

                    <div className="market-price-record-copy min-w-0 flex-1">
                      <div className="market-price-record-title-row flex items-start gap-2">
                        <h3 title={item.commodity} className="market-price-record-title min-w-0 text-lg font-bold text-green-900">
                          {item.commodity}
                        </h3>

                        <span className="text-sm">
                          {item.icon}
                        </span>

                      </div>

                      <p title={`${item.variety} • ${item.market}`} className="market-price-record-market mt-1 text-sm text-gray-500">
                        {item.variety} • {item.market}
                      </p>

                      <p title={[item.mandal, item.district, item.state].filter(Boolean).join(", ")} className="market-price-record-location text-sm text-gray-500">
                        {[item.mandal, item.district, item.state]
                          .filter(Boolean)
                          .join(", ")}
                      </p>
                    </div>
                  </div>

                  <div className="market-prices-record-values mt-3 grid grid-cols-3 gap-2">
                    <div className="market-prices-price-tile market-prices-price-tile--low rounded-xl p-3 text-center">
                      <p className="text-xs text-gray-500">
                        {t("minPrice", {}, language)}
                      </p>
                      <p className="font-bold text-gray-800 mt-1">
                        {formatCurrency(
                          item.minimumPrice
                        )}
                      </p>
                    </div>

                    <div className="market-prices-price-tile market-prices-price-tile--modal rounded-xl p-3 text-center">
                      <p className="text-xs text-gray-500">
                        {t("modalPrice", {}, language)}
                      </p>
                      <p className="font-bold text-green-800 mt-1">
                        {formatCurrency(
                          item.modalPrice
                        )}
                      </p>
                    </div>

                    <div className="market-prices-price-tile market-prices-price-tile--high rounded-xl p-3 text-center">
                      <p className="text-xs text-gray-500">
                        {t("maxPrice", {}, language)}
                      </p>
                      <p className="font-bold text-gray-800 mt-1">
                        {formatCurrency(
                          item.maximumPrice
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="market-price-card-footer mt-3 flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs text-gray-500">
                      {!item.arrivalTimestamp
                        ? t("marketPriceDateUnavailable", {}, language)
                        : Date.now() - item.arrivalTimestamp > 7 * 24 * 60 * 60 * 1000
                          ? t("marketPriceHistorical", {}, language)
                          : t("marketPriceLatest", {}, language)}
                      {" · "}{t("dateLabel", {}, language)} {item.arrivalDate || t("notAvailable", {}, language)}
                      {" · "}{item.source}
                    </p>

                    <button
                      type="button"
                      onClick={() => {
                        window.open(
                          `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                            `${item.market}, ${item.district}, ${item.state}`
                          )}`,
                          "_blank",
                          "noopener,noreferrer"
                        );
                      }}
                      className="market-prices-map-action rounded-xl px-3 py-2 text-sm font-semibold"
                    >
                      {t("openMarket", {}, language)}
                    </button>
                  </div>
                </article>
              ))}
              {filteredPrices.length > visibleRecordLimit && (
                <button
                  type="button"
                  onClick={() => setVisibleRecordLimit((limit) => limit + 60)}
                  className="mx-auto block rounded-xl border border-green-200 bg-white px-5 py-3 font-semibold text-green-800"
                >
                  {t("marketShowMoreRecords", {}, language)}
                </button>
              )}
            </div>
          )}
        </section>

        <section className="market-prices-section market-prices-nearby mt-6 mb-6">
          <div className="flex items-center justify-between gap-3 mb-3">
            <h2 className="text-xl font-bold text-green-900">
              {t("nearbySellingPlaces", {}, language)}
            </h2>

            <button
              type="button"
              onClick={openGeneralMapSearch}
              className="market-prices-primary-action rounded-xl px-4 py-2 font-semibold"
            >
              {t("searchInMaps", {}, language)}
            </button>
          </div>
          <p className="mb-3 text-xs text-gray-500">
            {t("marketNearbySourceNotice", {}, language)}{" "}
            <a className="underline" href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">© OpenStreetMap contributors</a>.
          </p>

          {loadingSellingPoints ? (
            <div className="market-prices-empty rounded-2xl border p-6 text-center">
              <p className="text-gray-600">
                {t("searchingNearbyPlaces", {}, language)}
              </p>
            </div>
          ) : sellingPoints.length === 0 ? (
            <div className="market-prices-empty rounded-2xl border p-6 text-center">
              <p className="text-gray-600">
                {t("noMappedPlaces", {}, language)}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {sellingPoints.map((point) => (
                <article
                  key={point.id}
                  className="market-prices-card market-prices-place-card rounded-2xl border p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="text-lg font-bold text-green-900">
                        {point.name}
                      </h3>

                      <p className="text-sm text-gray-600 mt-1">
                        {point.type}
                      </p>

                      <p className="text-sm text-gray-500 mt-1">
                        {point.address || t("addressNotAvailable", {}, language)}
                      </p>

                      <p className="text-sm text-gray-500 mt-1">
                        {t("distanceLabel", {}, language)} {point.distance.toFixed(1)} km
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-4">
                    <button
                      type="button"
                      onClick={() =>
                        openDirections(point)
                      }
                      className="market-prices-map-action rounded-xl px-4 py-2 font-semibold"
                    >
                      {t("directions", {}, language)}
                    </button>

                    {point.phone && (
                      <a
                        href={`tel:${point.phone}`}
                        className="market-prices-primary-action rounded-xl px-4 py-2 font-semibold"
                      >
                        {t("call", {}, language)}
                      </a>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
